Disk Cleanup - by SL_Linux   v1.3.0
Install (recommended): sudo apt install ./linux-disk-cleanup_1.3.0_all.deb
Or from this folder:   sudo ./install.sh        Remove: sudo ./uninstall.sh
Check your setup:      linux-disk-cleanup --selfcheck
Preview, no changes:   python3 ldc_core.py
Run the safety tests:  python3 -m unittest discover -s tests -v
System cleanup needs the installed version (the admin helper only runs from a
root-owned folder). Running from this folder cleans your own files only.
Translators: po/linux-disk-cleanup.pot

#!/usr/bin/env bash
# Installs "Disk Cleanup - by SL_Linux" system-wide. Everything is root-owned so the
# admin helper cannot be tampered with by normal users.
set -e
if [ "$(id -u)" -ne 0 ]; then
  echo "Administrator permission is needed to install. Re-running with sudo..."
  exec sudo bash "$0" "$@"
fi
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST=/opt/linux-disk-cleanup

need=""
python3 -c "import gi; gi.require_version('Gtk','3.0'); from gi.repository import Gtk" 2>/dev/null || need="$need python3-gi gir1.2-gtk-3.0"
command -v pkexec >/dev/null 2>&1 || need="$need pkexec"
if [ -n "$need" ]; then
  echo "Installing dependencies:$need"
  apt-get update -qq || true
  apt-get install -y $need || { [ "$need" = " pkexec" ] && apt-get install -y policykit-1; }
fi

rm -rf "$DEST"
install -d -m 755 "$DEST" "$DEST/assets"
install -m 644 "$SRC/ldc_core.py" "$DEST/ldc_core.py"
install -m 755 "$SRC/ldc_gui.py"  "$DEST/ldc_gui.py"
install -m 755 "$SRC/ldc-helper"  "$DEST/ldc-helper"
install -m 644 "$SRC"/assets/* "$DEST/assets/"
install -d -m 755 /usr/share/icons/hicolor/scalable/apps /usr/share/polkit-1/actions /usr/lib/systemd/user
install -m 644 "$SRC/assets/linux-disk-cleanup.svg" /usr/share/icons/hicolor/scalable/apps/linux-disk-cleanup.svg
install -m 644 "$SRC/extra/org.slinux.diskcleanup.policy" /usr/share/polkit-1/actions/org.slinux.diskcleanup.policy
install -m 644 "$SRC"/extra/linux-disk-cleanup-reminder.* /usr/lib/systemd/user/

cat > /usr/bin/linux-disk-cleanup <<'LAUNCH'
#!/bin/sh
exec /usr/bin/python3 /opt/linux-disk-cleanup/ldc_gui.py "$@"
LAUNCH
chmod 755 /usr/bin/linux-disk-cleanup

cat > /usr/share/applications/linux-disk-cleanup.desktop <<'DESK'
[Desktop Entry]
Type=Application
Name=Disk Cleanup - by SL_Linux
GenericName=Disk Cleanup
Comment=Free disk space by removing temporary files, caches and old logs
Exec=linux-disk-cleanup
Icon=linux-disk-cleanup
Terminal=false
Categories=System;Utility;
Keywords=cleanup;temp;cache;logs;disk;SL_Linux;
StartupWMClass=ldc_gui.py
DESK
chmod 644 /usr/share/applications/linux-disk-cleanup.desktop
command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q -t -f /usr/share/icons/hicolor 2>/dev/null || true
command -v update-desktop-database >/dev/null && update-desktop-database /usr/share/applications 2>/dev/null || true
echo "Done. Open 'Disk Cleanup - by SL_Linux' from the menu, or run: linux-disk-cleanup"
echo "Check your setup any time with: linux-disk-cleanup --selfcheck"

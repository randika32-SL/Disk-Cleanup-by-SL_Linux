#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Disk Cleanup - by SL_Linux : engine (no GUI imports).

Jobs:
  1. scan   - find cleanable files, always as the normal user, no password
  2. clean  - user items are removed by the GUI process; system items are
              removed by the root-owned helper (ldc-helper) started via pkexec.
              The helper never trusts paths from the GUI: it re-scans itself
              and only touches items that are still valid candidates AND
              were selected.

Safety rules baked in
  * fixed, well-known cache / temp / rotated-log locations only
  * every delete is checked against an allow-list of root folders
  * symlinks are removed, never followed
  * files that are open or memory-mapped by a running program are skipped
  * every item is re-validated right before it is deleted
  * your exclusion list is always honoured
  * the admin helper refuses to run unless it is root-owned and not writable
    by normal users (so it cannot be swapped for something malicious)
  * the running kernel and the newest older/newer kernel are never removed
"""
import errno
import fcntl
import gettext
import glob
import hashlib
import heapq
import json
import os
import re
import shlex
import shutil
import stat
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed, CancelledError
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

VERSION = "1.3.0"
APP_ID = "linux-disk-cleanup"
APP_BRAND = "Disk Cleanup - by SL_Linux"

_t = gettext.translation(APP_ID, "/usr/share/locale", fallback=True)
_ = _t.gettext

HOME = os.path.expanduser("~")
CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME") or f"{HOME}/.config", APP_ID)
DATA_DIR = os.path.join(os.environ.get("XDG_DATA_HOME") or f"{HOME}/.local/share", APP_ID)
STATE_DIR = os.path.join(os.environ.get("XDG_STATE_HOME") or f"{HOME}/.local/state", APP_ID)

DAY = 86400
TMP_MIN_AGE_DAYS = 2
VARTMP_MIN_AGE_DAYS = 30
JOURNAL_KEEP = "7d"
MAX_ENTRIES = 1000
HELPER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ldc-helper")
POLICY_FILE = "/usr/share/polkit-1/actions/org.slinux.diskcleanup.policy"

SCAN_CANCEL = threading.Event()
CLEAN_CANCEL = threading.Event()


def request_cancel():
    SCAN_CANCEL.set()
    CLEAN_CANCEL.set()


class Skipped(Exception):
    """An item was deliberately NOT removed (in use, changed, protected...)."""


class AuthCancelled(Exception):
    pass


class HelperRefused(Exception):
    pass


# --------------------------------------------------------------------------
# settings (stored per user, never any password)
# --------------------------------------------------------------------------
DEFAULT_SETTINGS = {
    "dry_run": False,            # preview only - delete nothing
    "trash_user_files": False,   # send /tmp files to Trash instead of deleting
    "exclusions": [],            # folders (start with /) or names to never clean
    "history": False,            # keep a local log of cleanups (no file names)
    "reminder": False,           # monthly "you could free X" notification
    "reminder_min_mb": 500,
    "warn_open_apps": True,      # ask to save & close open programs before cleaning
}


def load_settings():
    s = dict(DEFAULT_SETTINGS)
    s["exclusions"] = []
    try:
        with open(os.path.join(CONFIG_DIR, "settings.json"), encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            for k, v in data.items():
                if k in DEFAULT_SETTINGS and type(v) is type(DEFAULT_SETTINGS[k]):
                    s[k] = v
    except (OSError, ValueError):
        pass
    s["exclusions"] = [x for x in s["exclusions"] if isinstance(x, str) and x.strip()]
    return s


def save_settings(s):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    tmp = os.path.join(CONFIG_DIR, "settings.json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({k: s.get(k, v) for k, v in DEFAULT_SETTINGS.items()}, f, indent=2)
    os.replace(tmp, os.path.join(CONFIG_DIR, "settings.json"))


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def human(n):
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


def _env(extra=None):
    env = dict(os.environ, LC_ALL="C", LANG="C")
    if extra:
        env.update(extra)
    return env


def _run(cmd, env=None, timeout=1800):
    r = subprocess.run(cmd, capture_output=True, text=True,
                       env=env or _env(), timeout=timeout)
    if r.returncode != 0:
        text = (r.stderr or r.stdout or "").strip().splitlines()
        raise RuntimeError(text[-1] if text else f"command failed (exit {r.returncode})")
    return r.stdout


def _sig_of(st):
    return f"{st.st_dev}:{st.st_ino}:{stat.S_IFMT(st.st_mode)}"


def tree_info(path):
    """(disk_bytes, newest_mtime, has_socket_or_pipe). Never follows symlinks."""
    try:
        st = os.lstat(path)
    except OSError:
        return 0, 0.0, False
    size = st.st_blocks * 512
    newest = st.st_mtime
    special = stat.S_ISSOCK(st.st_mode) or stat.S_ISFIFO(st.st_mode)
    if stat.S_ISDIR(st.st_mode):
        seen = set()
        stack = [path]
        while stack:
            if SCAN_CANCEL.is_set():
                break
            d = stack.pop()
            try:
                with os.scandir(d) as it:
                    for e in it:
                        try:
                            s = e.stat(follow_symlinks=False)
                        except OSError:
                            continue
                        isdir = stat.S_ISDIR(s.st_mode)
                        if not isdir and s.st_nlink > 1:
                            k = (s.st_dev, s.st_ino)
                            if k in seen:
                                continue
                            seen.add(k)
                        size += s.st_blocks * 512
                        if s.st_mtime > newest:
                            newest = s.st_mtime
                        if stat.S_ISSOCK(s.st_mode) or stat.S_ISFIFO(s.st_mode):
                            special = True
                        if isdir:
                            stack.append(e.path)
            except OSError:
                continue
    return size, newest, special


def open_paths():
    """Every file currently open, mapped into memory, or used as a working
    directory by any process we are allowed to inspect (root sees all)."""
    paths = set()
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except OSError:
        return paths
    for pid in pids:
        base = f"/proc/{pid}"
        try:
            for fd in os.listdir(base + "/fd"):
                try:
                    t = os.readlink(f"{base}/fd/{fd}")
                except OSError:
                    continue
                if t.startswith("/"):
                    paths.add(t.replace(" (deleted)", ""))
        except OSError:
            pass
        try:
            paths.add(os.readlink(base + "/cwd"))
        except OSError:
            pass
        try:
            with open(base + "/maps", errors="replace") as f:
                for line in f:
                    parts = line.split(None, 5)
                    if len(parts) == 6 and parts[5].startswith("/"):
                        paths.add(parts[5].strip().replace(" (deleted)", ""))
        except OSError:
            pass
    return paths


def running_names():
    names = set()
    try:
        for pid in os.listdir("/proc"):
            if pid.isdigit():
                try:
                    with open(f"/proc/{pid}/comm") as f:
                        names.add(f.read().strip())
                except OSError:
                    pass
    except OSError:
        pass
    return names


APT_PROCS = {"apt", "apt-get", "dpkg", "aptitude", "unattended-upgr", "apt.systemd.dai"}


def apt_busy():
    """True if apt/dpkg is running or holding its lock (checked by root too)."""
    if APT_PROCS & running_names():
        return True
    for lock in ("/var/lib/dpkg/lock-frontend", "/var/lib/dpkg/lock",
                 "/var/lib/apt/lists/lock", "/var/cache/apt/archives/lock"):
        try:
            fd = os.open(lock, os.O_RDWR)
        except OSError:
            continue
        try:
            fcntl.lockf(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.lockf(fd, fcntl.LOCK_UN)
        except OSError:
            return True
        finally:
            os.close(fd)
    return False


# --------------------------------------------------------------------------
# open programs check ("save your work and close these before cleaning")
# --------------------------------------------------------------------------
TERMINAL_PROCS = {
    "gnome-terminal-": "GNOME Terminal", "gnome-terminal": "GNOME Terminal", "xterm": "XTerm",
    "uxterm": "XTerm", "konsole": "Konsole", "tilix": "Tilix", "alacritty": "Alacritty",
    "kitty": "Kitty", "xfce4-terminal": "Xfce Terminal", "terminator": "Terminator",
    "mate-terminal": "MATE Terminal", "qterminal": "QTerminal", "lxterminal": "LXTerminal",
    "st": "st", "foot": "Foot", "wezterm": "WezTerm", "wezterm-gui": "WezTerm", "guake": "Guake",
    "tilda": "Tilda", "terminology": "Terminology", "urxvt": "URxvt", "rxvt": "RXVT",
    "sakura": "Sakura", "cool-retro-term": "Cool Retro Term", "ptyxis": "Ptyxis",
    "kgx": "GNOME Console", "blackbox": "Black Box", "deepin-terminal": "Deepin Terminal",
    "tmux: server": "tmux", "screen": "screen", "SCREEN": "screen",
}
SHELLS = {"bash", "zsh", "fish", "sh", "dash", "ksh", "tcsh", "csh"}
# background helpers that have a menu entry but are not "open programs" in the user's mind
IGNORE_APPS = {"nm-applet", "blueman-applet", "mintupdate", "mintreport", "xapp-sn-watcher",
               "evolution-alarm-notify", "gnome-software", "redshift-gtk", "pasystray",
               "ibus-ui-gtk3", "fcitx", "fcitx5", "tracker-miner-fs-3", "polkit-gnome-authentication-agent-1"}
SERVICE_FLAGS = {"--gapplication-service", "--daemon", "--gapplication-replace"}
GENERIC_PROGRAMS = {"env", "sh", "bash", "dash", "python", "python3", "java", "flatpak", "snap",
                    "xdg-open", "pkexec", "sudo", "gtk-launch", "gio", "dbus-launch",
                    "dbus-run-session", "systemd-run", "nohup", "setsid", "wine", "wine64",
                    "mono", "ruby", "node", "perl", "electron", "bwrap", "xdg-dbus-proxy"}
INTERPRETERS = ("python", "perl", "ruby", "node")
DESKTOP_DIRS = ["/usr/share/applications", "/usr/local/share/applications",
                f"{HOME}/.local/share/applications",
                "/var/lib/flatpak/exports/share/applications",
                f"{HOME}/.local/share/flatpak/exports/share/applications",
                "/var/lib/snapd/desktop/applications"]
KIND_ORDER = {"browser": 0, "terminal": 1, "app": 2}
_DESK_CACHE = [0.0, None]


def _parse_desktop(path):
    d, in_entry = {}, False
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line.startswith("["):
                    in_entry = (line == "[Desktop Entry]")
                elif in_entry and "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    d.setdefault(k.strip(), v.strip())
    except OSError:
        pass
    return d


def _exec_programs(exec_line, depth=0):
    """Program names a menu entry's Exec= line will start (as seen in /proc)."""
    try:
        toks = shlex.split(exec_line)
    except ValueError:
        toks = exec_line.split()
    while toks and (toks[0] == "env" or re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", toks[0])):
        toks.pop(0)
    if not toks:
        return []
    base = os.path.basename(toks.pop(0))
    names = []
    if base == "flatpak":
        names += [t.split("=", 1)[1] for t in toks if t.startswith("--command=")]
        ids = [t for t in toks if not t.startswith(("-", "@", "%")) and t != "run"]
        names += ids[:1]
    elif base in ("sh", "bash") and "-c" in toks and depth < 2:
        i = toks.index("-c")
        if i + 1 < len(toks):
            names += _exec_programs(toks[i + 1], depth + 1)
    else:
        names.append(base)
        if base.startswith(INTERPRETERS):
            script = next((t for t in toks if not t.startswith("-")), "")
            if script:
                b = os.path.basename(script)
                names += [b, b[:-3] if b.endswith(".py") else b]
    return [n for n in names if n and n not in GENERIC_PROGRAMS]


def desktop_map(dirs=None):
    """{program name: (display name, kind)} from installed menu entries."""
    if dirs is None and _DESK_CACHE[1] is not None and time.time() - _DESK_CACHE[0] < 60:
        return _DESK_CACHE[1]
    out = {}
    for d in (dirs if dirs is not None else DESKTOP_DIRS):
        for path in sorted(glob.glob(os.path.join(d, "*.desktop"))):
            e = _parse_desktop(path)
            if e.get("Type") != "Application" or not e.get("Name") or not e.get("Exec"):
                continue
            if e.get("NoDisplay", "").lower() == "true" or e.get("Hidden", "").lower() == "true":
                continue
            if e.get("Terminal", "").lower() == "true":      # text apps live inside a terminal
                continue
            cats = e.get("Categories", "")
            kind = "terminal" if "TerminalEmulator" in cats else \
                "browser" if "WebBrowser" in cats else "app"
            for prog in _exec_programs(e["Exec"]):
                out.setdefault(prog, (e["Name"], kind))
                out.setdefault(prog[:15], (e["Name"], kind))   # /proc comm is cut at 15 characters
    if dirs is None:
        _DESK_CACHE[0], _DESK_CACHE[1] = time.time(), out
    return out


def _window_pids():
    """PIDs that own a window (needs wmctrl on X11). None = cannot tell."""
    if os.environ.get("XDG_SESSION_TYPE") == "wayland" or not shutil.which("wmctrl"):
        return None
    try:
        r = subprocess.run(["wmctrl", "-lp"], capture_output=True, text=True, timeout=5)
    except Exception:
        return None
    if r.returncode != 0:
        return None
    pids = set()
    for line in r.stdout.splitlines():
        parts = line.split(None, 4)
        if len(parts) >= 3 and parts[2].isdigit() and int(parts[2]) > 0:
            pids.add(int(parts[2]))
    return pids


def _proc_info(proc, pid):
    base = f"{proc}/{pid}"
    try:
        with open(base + "/comm", errors="replace") as f:
            comm = f.read().strip()
    except OSError:
        return None
    try:
        exe = os.path.basename(os.readlink(base + "/exe")).replace(" (deleted)", "")
    except OSError:
        exe = ""
    try:
        with open(base + "/cmdline", "rb") as f:
            argv = [a.decode(errors="replace") for a in f.read().split(b"\0") if a]
    except OSError:
        argv = []
    ppid = tty = 0
    try:
        with open(base + "/stat", errors="replace") as f:
            st = f.read()
        rest = st[st.rfind(")") + 2:].split()
        ppid, tty = int(rest[1]), int(rest[4])
    except (OSError, ValueError, IndexError):
        pass
    return {"pid": int(pid), "comm": comm, "exe": exe, "argv": argv, "ppid": ppid, "tty": tty}


def _self_and_ancestors(proc="/proc"):
    pids, pid = set(), os.getpid()
    while pid > 1 and pid not in pids:
        pids.add(pid)
        info = _proc_info(proc, pid)
        if not info:
            break
        pid = info["ppid"]
    return pids


def detect_open_apps(proc="/proc", uid=None, exclude_pids=None, dirs=None, window_pids="auto"):
    """Programs of the current user that are open right now: browsers, terminals
    and other applications. Returns [{"name", "kind", "count"}]. This program and
    the terminal it was started from are not listed."""
    uid = os.getuid() if uid is None else uid
    exclude = _self_and_ancestors(proc) if exclude_pids is None else set(exclude_pids)
    dmap = desktop_map(dirs)
    groups = {}          # (kind, name) -> set(pids)
    shells = {}
    try:
        pids = [p for p in os.listdir(proc) if p.isdigit()]
    except OSError:
        return []
    for p in pids:
        pid = int(p)
        if pid in exclude:
            continue
        try:
            if os.stat(f"{proc}/{p}").st_uid != uid:
                continue
        except OSError:
            continue
        info = _proc_info(proc, p)
        if not info:
            continue
        comm, exe, argv = info["comm"], info["exe"], info["argv"]
        keys = [comm, comm[:15], exe, os.path.basename(argv[0]) if argv else ""]
        if (exe or comm).startswith(INTERPRETERS) and len(argv) > 1:
            b = os.path.basename(argv[1])
            keys += [b, b[:-3] if b.endswith(".py") else b]
        keys = [k for k in keys if k]
        # 1) browsers
        browser = next((lbl for lbl, names in BROWSER_PROCS.items() if names & set(keys)), None)
        if browser:
            groups.setdefault(("browser", browser), set()).add(pid)
            continue
        # 2) terminal programs
        term = next((TERMINAL_PROCS[k] for k in keys if k in TERMINAL_PROCS), None)
        if term:
            groups.setdefault(("terminal", term), set()).add(pid)
            continue
        # 3) shells sitting in a terminal
        if comm in SHELLS and info["tty"]:
            try:
                tty = os.readlink(f"{proc}/{p}/fd/0")
            except OSError:
                tty = ""
            if tty.startswith(("/dev/pts", "/dev/tty")):
                shells.setdefault(("terminal", _("Terminal session (%s)") % comm), set()).add(pid)
            continue
        # 4) other applications with a menu entry
        if set(argv[1:]) & SERVICE_FLAGS or comm in IGNORE_APPS or exe in IGNORE_APPS:
            continue
        for k in keys:
            if k in dmap and k not in IGNORE_APPS:
                name, kind = dmap[k]
                groups.setdefault((kind, name), set()).add(pid)
                break
    if not any(k[0] == "terminal" for k in groups):      # a terminal window already covers its shells
        groups.update(shells)
    wp = _window_pids() if window_pids == "auto" else window_pids
    if wp is not None:
        groups = {k: v for k, v in groups.items() if k[0] != "app" or (v & wp)}
    out = [{"name": n, "kind": k, "count": len(v)} for (k, n), v in groups.items()]
    out.sort(key=lambda a: (KIND_ORDER.get(a["kind"], 9), a["name"].lower()))
    return out


def friendly(ex):
    """Turn an exception into a short sentence that says what to do."""
    if isinstance(ex, Skipped):
        return str(ex)
    if isinstance(ex, subprocess.TimeoutExpired):
        return _("This took too long and was stopped. Try again later.")
    if isinstance(ex, FileNotFoundError):
        return _("Already gone.")
    if isinstance(ex, PermissionError):
        return _("No permission to remove this. It may belong to another user or be protected.")
    if isinstance(ex, OSError):
        if ex.errno == errno.EBUSY:
            return _("In use right now. Close the app that uses it, then rescan.")
        if ex.errno == errno.EROFS:
            return _("This location is read-only.")
        if ex.errno == errno.ENOTEMPTY:
            return _("The folder still contains items that are in use.")
    msg = str(ex)
    low = msg.lower()
    if "could not get lock" in low or "unable to acquire" in low or "lock" in low and "dpkg" in low:
        return _("The package manager is busy. Wait for updates to finish and try again.")
    if "not found" in low and "command" in low:
        return _("A required tool is missing on this system.")
    return msg


# --------------------------------------------------------------------------
# data model
# --------------------------------------------------------------------------
@dataclass
class Entry:
    cat: str
    key: str                 # full path, or an identifier for command-type items
    label: str
    location: str
    size: int
    approx: bool = False
    detail: str = ""
    sig: str = ""            # identity of the item at scan time (dev:inode:type)
    warn: str = ""           # shown next to the item, e.g. "app is running"
    data: list = field(default_factory=list)


@dataclass
class Category:
    id: str
    name: str
    desc: str
    where: str
    scope: str                  # "user" or "system" (system = needs admin)
    roots: List[str]            # allow-list used by every delete
    enum: Callable[[], List[Entry]]
    default: bool = False       # ticked by default
    advanced: bool = False      # needs an extra "I have reviewed this" tick
    trashable: bool = False     # may be sent to Trash when the user asks
    min_age_days: Optional[float] = None
    pkg_manager: bool = False   # needs apt/dpkg to be idle


def _children(base):
    try:
        with os.scandir(base) as it:
            return sorted(e.path for e in it)
    except OSError:
        return []


def _entry(cat_id, path, label, location, size, st=None, **kw):
    if st is None:
        try:
            st = os.lstat(path)
        except OSError:
            st = None
    return Entry(cat_id, path, label, location, size, sig=_sig_of(st) if st else "", **kw)


def is_excluded(e, exclusions):
    """Folder exclusions (start with /) protect that folder and everything in
    it. Other exclusions are names, matched case-insensitively against the
    item's name or path."""
    for x in exclusions or []:
        x = x.strip()
        if not x:
            continue
        if x.startswith("/"):
            x = x.rstrip("/") or "/"
            if e.key == x or e.key.startswith(x.rstrip("/") + "/"):
                return True
        else:
            low = x.lower()
            if low in e.label.lower() or (e.key.startswith("/") and low in e.key.lower()):
                return True
    return False


def _dir_entries(cat_id, base, skip=None, min_age_days=None, uid=None, skip_special=False):
    out = []
    now = time.time()
    for p in _children(base):
        if SCAN_CANCEL.is_set():
            break
        name = os.path.basename(p)
        if skip and skip(name):
            continue
        try:
            st = os.lstat(p)
        except OSError:
            continue
        if uid is not None and st.st_uid != uid:
            continue
        if stat.S_ISSOCK(st.st_mode) or stat.S_ISFIFO(st.st_mode):
            continue
        size, newest, special = tree_info(p)
        if skip_special and special:
            continue
        if min_age_days is not None and now - max(newest, st.st_ctime) < min_age_days * DAY:
            continue
        out.append(_entry(cat_id, p, name, base, size, st))
    out.sort(key=lambda e: e.size, reverse=True)
    return out[:MAX_ENTRIES]


def _fixed(cat_id, items):
    out = []
    for label, path in items:
        if SCAN_CANCEL.is_set():
            break
        if not os.path.lexists(path) or os.path.islink(path):
            continue
        size, _n, _s = tree_info(path)
        if size <= 4096:
            continue
        out.append(_entry(cat_id, path, label, os.path.dirname(path), size))
    out.sort(key=lambda e: e.size, reverse=True)
    return out


# --------------------------------------------------------------------------
# USER categories (no password needed)
# --------------------------------------------------------------------------
def enum_thumbnails():
    return (_dir_entries("thumbnails", f"{HOME}/.cache/thumbnails")
            + _dir_entries("thumbnails", f"{HOME}/.thumbnails"))


CACHE_SKIP = {
    "thumbnails", "mozilla", "google-chrome", "chromium", "BraveSoftware",
    "microsoft-edge", "opera", "pip", "yarn", "go-build",
    "dconf", "keyring", "ibus", "ldc",
}


def enum_user_cache():
    return _dir_entries("user_cache", f"{HOME}/.cache", skip=lambda n: n in CACHE_SKIP)


BROWSER_PROCS = {
    "Firefox": {"firefox", "firefox-bin", "firefox-esr"},
    "Google Chrome": {"chrome"},
    "Chromium": {"chromium", "chromium-browse"},
    "Brave": {"brave"},
    "Microsoft Edge": {"msedge"},
    "Opera": {"opera"},
}


def browser_running(label):
    procs = BROWSER_PROCS.get(label.split(" (")[0], set())
    return bool(procs & running_names())


def enum_browser():
    items = [
        ("Firefox", f"{HOME}/.cache/mozilla/firefox"),
        ("Firefox (Snap)", f"{HOME}/snap/firefox/common/.cache"),
        ("Google Chrome", f"{HOME}/.cache/google-chrome"),
        ("Chromium", f"{HOME}/.cache/chromium"),
        ("Chromium (Snap)", f"{HOME}/snap/chromium/common/.cache"),
        ("Brave", f"{HOME}/.cache/BraveSoftware"),
        ("Microsoft Edge", f"{HOME}/.cache/microsoft-edge"),
        ("Opera", f"{HOME}/.cache/opera"),
    ]
    out = _fixed("browser", items)
    names = running_names()
    for e in out:
        if BROWSER_PROCS.get(e.label.split(" (")[0], set()) & names:
            e.warn = _("running - will be skipped")
    return out


TMP_SKIP_PREFIXES = (
    ".X", ".ICE", ".font-unix", ".XIM", ".Test", "systemd-private",
    "snap-private", "ssh-", "runtime-", "pulse", "dbus-", "tracker-",
    "keyring", "gdm", "orbit", "ldc-",
)


def enum_user_tmp():
    return _dir_entries(
        "user_tmp", "/tmp", skip=lambda n: n.startswith(TMP_SKIP_PREFIXES),
        min_age_days=TMP_MIN_AGE_DAYS, uid=os.getuid(), skip_special=True)


def enum_trash():
    return _dir_entries("trash", f"{HOME}/.local/share/Trash/files")


def enum_dev():
    return _fixed("dev", [
        ("pip cache", f"{HOME}/.cache/pip"),
        ("npm cache", f"{HOME}/.npm/_cacache"),
        ("Yarn cache", f"{HOME}/.cache/yarn"),
        ("Go build cache", f"{HOME}/.cache/go-build"),
    ])


def enum_flatpak_cache():
    items = [(os.path.basename(os.path.dirname(p)), p)
             for p in sorted(glob.glob(f"{HOME}/.var/app/*/cache"))]
    return _fixed("flatpak_cache", items)


def enum_xerrors():
    items = [("Old session errors", f"{HOME}/.xsession-errors.old")]
    items += [(os.path.basename(p), p)
              for p in sorted(glob.glob(f"{HOME}/.local/share/xorg/*.log.old"))]
    out = []
    for label, p in items:
        try:
            st = os.lstat(p)
        except OSError:
            continue
        if stat.S_ISREG(st.st_mode):
            out.append(_entry("xerrors", p, label, os.path.dirname(p), st.st_blocks * 512, st))
    return out


# ---- units / parsing helpers -------------------------------------------
_UNITS = {"B": 1, "BYTES": 1, "KB": 1000, "MB": 1000 ** 2, "GB": 1000 ** 3, "TB": 1000 ** 4}


def parse_size(num, unit):
    return int(float(num.replace(",", "")) * _UNITS.get(unit.upper(), 1))


# ---- Flatpak -------------------------------------------------------------
def parse_flatpak_unused(text):
    """[(app_id, branch)] from the table `flatpak uninstall --unused` prints."""
    return re.findall(r"^\s*\d+\.\s+(\S+)\s+(\S+)\s+r\b", text, re.M)


def parse_flatpak_sizes(text):
    sizes = {}
    for line in text.splitlines():
        parts = [p.strip() for p in line.split("\t")]
        if len(parts) >= 3:
            m = re.match(r"^([\d.,]+)\s*(bytes|[kKMGT]?B)$", parts[2])
            if m:
                sizes[(parts[0], parts[1])] = parse_size(m.group(1), m.group(2))
    return sizes


def _flatpak_unused(scope, cat_id):
    if not shutil.which("flatpak"):
        return []
    try:
        r = subprocess.run(["flatpak", "uninstall", "--unused", scope, "--assumeno",
                            "--noninteractive"], capture_output=True, text=True,
                           timeout=60, env=_env())
        refs = parse_flatpak_unused(r.stdout + "\n" + r.stderr)
        if not refs:
            return []
        lst = subprocess.run(["flatpak", "list", "--runtime", scope,
                              "--columns=application,branch,size"],
                             capture_output=True, text=True, timeout=60, env=_env())
        sizes = parse_flatpak_sizes(lst.stdout)
    except Exception:
        return []
    names = sorted(f"{a}//{b}" for a, b in refs)
    size = sum(sizes.get(r, 0) for r in refs)
    digest = hashlib.sha1("\n".join(names).encode()).hexdigest()[:12]
    who = "your" if scope == "--user" else "system-wide"
    return [Entry(cat_id, f"flatpak:{scope}:{digest}",
                  f"{len(names)} unused Flatpak runtime(s) ({who})", "Flatpak", size,
                  approx=True, data=[scope],
                  detail="Runtimes no installed app needs:\n" + "\n".join(names))]


def enum_flatpak_user():
    return _flatpak_unused("--user", "flatpak_user")


def enum_flatpak_system():
    return _flatpak_unused("--system", "flatpak_system")


# ---- Docker --------------------------------------------------------------
def enum_docker():
    if not shutil.which("docker"):
        return []
    try:
        r = subprocess.run(["docker", "system", "df", "--format", "{{.Type}}|{{.Reclaimable}}"],
                           capture_output=True, text=True, timeout=20, env=_env())
    except Exception:
        return []
    if r.returncode != 0:
        return []
    total = 0
    for line in r.stdout.splitlines():
        m = re.search(r"\|\s*([\d.]+)\s*([kKMGT]?B)", line)
        if m:
            total += parse_size(m.group(1), m.group(2))
    if total <= 0:
        return []
    return [Entry("docker", "docker:prune", "Docker leftovers", "docker", total, approx=True,
                  detail="Removes stopped containers, dangling images, unused networks and "
                         "build cache (docker system prune). Data inside stopped containers is lost.")]


# --------------------------------------------------------------------------
# SYSTEM categories (need administrator permission to delete)
# --------------------------------------------------------------------------
def enum_apt_cache():
    base = "/var/cache/apt/archives"
    out = []
    for p in _children(base):
        try:
            st = os.lstat(p)
        except OSError:
            continue
        if p.endswith(".deb") and stat.S_ISREG(st.st_mode):
            out.append(_entry("apt_cache", p, os.path.basename(p), base, st.st_blocks * 512, st))
    out.sort(key=lambda e: e.size, reverse=True)
    return out[:MAX_ENTRIES]


ROTATED = re.compile(
    r"(\.(gz|xz|bz2|zst|old)|\.\d+(\.(gz|xz|bz2|zst))?|-\d{8}(\.(gz|xz|bz2|zst))?)$")


def enum_old_logs():
    base = "/var/log"
    out = []
    for dirpath, dirnames, filenames in os.walk(base, followlinks=False):
        if SCAN_CANCEL.is_set():
            break
        dirnames[:] = [d for d in dirnames if d != "journal"]
        for f in filenames:
            if not ROTATED.search(f):
                continue
            p = os.path.join(dirpath, f)
            try:
                st = os.lstat(p)
            except OSError:
                continue
            if stat.S_ISREG(st.st_mode):
                out.append(_entry("old_logs", p, os.path.relpath(p, base), dirpath,
                                  st.st_blocks * 512, st))
    out.sort(key=lambda e: e.size, reverse=True)
    return out[:MAX_ENTRIES]


def _journal_bytes():
    try:
        r = subprocess.run(["journalctl", "--disk-usage"], capture_output=True,
                           text=True, timeout=20, env=_env())
    except Exception:
        return 0
    m = re.search(r"take up\s+([\d.]+)\s*([KMGT]?)", r.stdout)
    if not m:
        return 0
    mult = {"": 1, "K": 1024, "M": 1024 ** 2, "G": 1024 ** 3, "T": 1024 ** 4}[m.group(2)]
    return int(float(m.group(1)) * mult)


def enum_journal():
    size = _journal_bytes()
    if size <= 0:
        return []
    keep = JOURNAL_KEEP.replace("d", " days")
    return [Entry("journal", "journal:vacuum", f"Journal entries older than {keep}",
                  "/var/log/journal", size, approx=True,
                  detail=f"Total journal size is shown. Only entries older than {keep} are "
                         "removed, so you will usually free less than this.")]


def enum_crash():
    out = []
    for base in ("/var/crash", "/var/lib/systemd/coredump"):
        for p in _children(base):
            try:
                st = os.lstat(p)
            except OSError:
                continue
            if stat.S_ISREG(st.st_mode):
                out.append(_entry("crash", p, os.path.basename(p), base, st.st_blocks * 512, st))
    out.sort(key=lambda e: e.size, reverse=True)
    return out[:MAX_ENTRIES]


def enum_var_tmp():
    return _dir_entries(
        "var_tmp", "/var/tmp",
        skip=lambda n: n.startswith(("systemd-private", "snap-private")),
        min_age_days=VARTMP_MIN_AGE_DAYS, skip_special=True)


# ---- unused packages (kernel-safe) ---------------------------------------
_PKG_OK = re.compile(r"^[a-z0-9][a-z0-9+.\-:]*$")


def _kernel_ver(pkg):
    m = re.match(r"^linux-(?:image(?:-unsigned)?|headers|modules(?:-extra)?|tools|buildinfo)"
                 r"-(\d+\.\d+\.\d+-\d+)", pkg)
    return m.group(1) if m else None


def _ver_tuple(v):
    return tuple(int(x) for x in re.split(r"[.-]", v))


def kernels_to_keep(installed, running):
    """Running kernel + newest newer one (pending reboot) + newest older one."""
    keep = set()
    others = [v for v in set(installed) if v != running]
    if running:
        keep.add(running)
        r = _ver_tuple(running)
        newer = [v for v in others if _ver_tuple(v) > r]
        older = [v for v in others if _ver_tuple(v) < r]
        if newer:
            keep.add(max(newer, key=_ver_tuple))
        if older:
            keep.add(max(older, key=_ver_tuple))
    else:
        keep |= set(sorted(others, key=_ver_tuple)[-2:])
    return keep


def _running_kernel_ver():
    m = re.match(r"(\d+\.\d+\.\d+-\d+)", os.uname().release)
    return m.group(1) if m else None


def _installed_kernel_versions():
    try:
        r = subprocess.run(["dpkg-query", "-W", "-f", "${db:Status-Abbrev} ${Package}\n",
                            "linux-image-*"], capture_output=True, text=True,
                           timeout=30, env=_env())
    except Exception:
        return []
    vers = []
    for line in r.stdout.splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[0].startswith("ii"):
            v = _kernel_ver(parts[1])
            if v:
                vers.append(v)
    return vers


def enum_autoremove():
    try:
        r = subprocess.run(["apt-get", "-s", "autoremove"], capture_output=True,
                           text=True, timeout=120, env=_env())
    except Exception:
        return []
    pkgs = sorted(set(re.findall(r"^Remv (\S+)", r.stdout, re.M)))
    pkgs = [p for p in pkgs if _PKG_OK.match(p)]
    if not pkgs:
        return []
    keep = kernels_to_keep(_installed_kernel_versions(), _running_kernel_ver())
    safe = [p for p in pkgs if _kernel_ver(p) not in keep]
    kept = [p for p in pkgs if p not in safe]
    if not safe:
        return []
    try:
        r2 = subprocess.run(["apt-get", "-s", "remove"] + safe, capture_output=True,
                            text=True, timeout=120, env=_env())
    except Exception:
        return []
    if set(re.findall(r"^Remv (\S+)", r2.stdout, re.M)) != set(safe):
        return []        # removing these would drag other packages along: do nothing
    size = 0
    m = re.search(r"After this operation, ([\d.,]+)\s*([kKMG]?B) disk space will be freed", r2.stdout)
    if m:
        size = parse_size(m.group(1), m.group(2))
    digest = hashlib.sha1("\n".join(safe).encode()).hexdigest()[:12]
    detail = "Packages that will be removed (settings files are kept):\n" + "\n".join(safe)
    if kept:
        detail += "\n\nKept for safety (running or neighbouring kernel):\n" + "\n".join(kept)
    return [Entry("autoremove", f"apt:autoremove:{digest}",
                  f"{len(safe)} unused package(s) (installed only as dependencies)",
                  "apt package database", size, approx=True, detail=detail, data=safe)]


def enum_snaps():
    if not shutil.which("snap"):
        return []
    try:
        out = _run(["snap", "list", "--all"], timeout=30)
    except Exception:
        return []
    res = []
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 6 or "disabled" not in parts[-1]:
            continue
        name, rev = parts[0], parts[2]
        try:
            size = os.lstat(f"/var/lib/snapd/snaps/{name}_{rev}.snap").st_blocks * 512
        except OSError:
            size = 0
        res.append(Entry("snaps", f"snap:{name}:{rev}", f"{name} (old revision {rev})",
                         "/var/lib/snapd/snaps", size))
    return res


# --------------------------------------------------------------------------
# registry
# --------------------------------------------------------------------------
H = HOME
CATEGORIES: List[Category] = [
    Category("thumbnails", _("Thumbnail cache"),
             _("Small image previews made by the file manager. Rebuilt automatically."),
             "~/.cache/thumbnails", "user",
             [f"{H}/.cache/thumbnails", f"{H}/.thumbnails"], enum_thumbnails, True),
    Category("user_cache", _("Application caches"),
             _("Temporary data apps keep in ~/.cache. They recreate it when needed."),
             "~/.cache", "user", [f"{H}/.cache"], enum_user_cache, True),
    Category("browser", _("Web browser caches"),
             _("Cached pages and images. Bookmarks, passwords and history are NOT touched. "
               "A browser that is running is skipped."),
             "~/.cache/<browser>", "user", [f"{H}/.cache", f"{H}/snap"], enum_browser, True),
    Category("user_tmp", _("Temporary files"),
             _("Your files in /tmp older than %d days (not in use).") % TMP_MIN_AGE_DAYS,
             "/tmp", "user", ["/tmp"], enum_user_tmp, True,
             trashable=True, min_age_days=TMP_MIN_AGE_DAYS),
    Category("flatpak_cache", _("Flatpak app caches"),
             _("Cache folders of Flatpak apps."),
             "~/.var/app/*/cache", "user", [f"{H}/.var/app"], enum_flatpak_cache, True),
    Category("xerrors", _("Old session error logs"),
             _("Rotated desktop-session logs (.old)."),
             "~/.xsession-errors.old", "user",
             [H, f"{H}/.local/share/xorg"], enum_xerrors, True),
    Category("trash", _("Trash"),
             _("Files you deleted earlier. Emptying them is permanent."),
             "~/.local/share/Trash", "user", [f"{H}/.local/share/Trash/files"],
             enum_trash, False),
    Category("dev", _("Developer caches"),
             _("pip, npm, Yarn and Go build caches. Re-downloaded when needed."),
             "~/.cache, ~/.npm", "user", [f"{H}/.cache", f"{H}/.npm"], enum_dev, False),

    Category("apt_cache", _("Downloaded package files (APT cache)"),
             _("Installer .deb files apt keeps after installing. Safe to remove."),
             "/var/cache/apt/archives", "system", ["/var/cache/apt/archives"],
             enum_apt_cache, True, pkg_manager=True),
    Category("old_logs", _("Old system logs"),
             _("Archived/rotated logs (.gz, .1, .old). Active logs are never listed."),
             "/var/log", "system", ["/var/log"], enum_old_logs, True),
    Category("crash", _("Crash reports and core dumps"),
             _("Debug data left behind by crashed programs."),
             "/var/crash, /var/lib/systemd/coredump", "system",
             ["/var/crash", "/var/lib/systemd/coredump"], enum_crash, True),
    Category("var_tmp", _("System temporary files"),
             _("Files in /var/tmp older than %d days (not in use).") % VARTMP_MIN_AGE_DAYS,
             "/var/tmp", "system", ["/var/tmp"], enum_var_tmp, True,
             min_age_days=VARTMP_MIN_AGE_DAYS),
    Category("snaps", _("Old Snap versions"),
             _("Disabled older revisions that Snap keeps after updates."),
             "/var/lib/snapd/snaps", "system", [], enum_snaps, False),

    # ---- Advanced: needs an extra confirmation tick -------------------------
    Category("journal", _("System journal (old entries)"),
             _("systemd journal entries older than %s.") % JOURNAL_KEEP.replace("d", " days"),
             "/var/log/journal", "system", [], enum_journal, False, advanced=True),
    Category("autoremove", _("Unused packages"),
             _("Dependencies nothing needs any more. The running kernel and its neighbours "
               "are always kept. Review the list first."),
             "apt", "system", [], enum_autoremove, False, advanced=True, pkg_manager=True),
    Category("flatpak_user", _("Unused Flatpak runtimes (your apps)"),
             _("Runtimes no installed Flatpak app needs."),
             "Flatpak (user)", "user", [], enum_flatpak_user, False, advanced=True),
    Category("flatpak_system", _("Unused Flatpak runtimes (system-wide)"),
             _("Runtimes no installed Flatpak app needs."),
             "Flatpak (system)", "system", [], enum_flatpak_system, False, advanced=True),
    Category("docker", _("Docker leftovers"),
             _("Stopped containers, dangling images, unused networks and build cache."),
             "docker", "user", [], enum_docker, False, advanced=True),
]
CAT_BY_ID: Dict[str, Category] = {c.id: c for c in CATEGORIES}


def scan_category(cat):
    try:
        return cat.enum()
    except Exception:
        return []


@dataclass
class ScanResult:
    entries: Dict[str, List[Entry]]
    hidden: int = 0          # items hidden by the exclusion list
    cancelled: bool = False


def scan_all(progress=None, exclusions=None):
    SCAN_CANCEL.clear()
    excl = exclusions or []
    res, hidden, done = {}, 0, 0
    with ThreadPoolExecutor(max_workers=4) as ex:
        futs = {ex.submit(scan_category, c): c for c in CATEGORIES}
        for f in as_completed(futs):
            c = futs[f]
            try:
                es = f.result()
            except (CancelledError, Exception):
                es = []
            kept = [e for e in es if not is_excluded(e, excl)]
            hidden += len(es) - len(kept)
            res[c.id] = kept
            done += 1
            if SCAN_CANCEL.is_set():
                for g in futs:
                    g.cancel()
            if progress:
                progress(done, len(CATEGORIES), c)
    for c in CATEGORIES:
        res.setdefault(c.id, [])
    return ScanResult(res, hidden, SCAN_CANCEL.is_set())


# --------------------------------------------------------------------------
# deleting
# --------------------------------------------------------------------------
class Ctx:
    """Options and caches for one cleanup run."""

    def __init__(self, dry_run=False, trash=False, protected=None):
        self.dry_run = dry_run
        self.trash = trash
        self.protected = [p.rstrip("/") or "/" for p in (protected or []) if p.startswith("/")]
        self._open = None

    @property
    def open_set(self):
        if self._open is None:
            self._open = open_paths()
        return self._open

    def is_protected(self, path):
        return any(path == p or path.startswith(p + "/") for p in self.protected)


def _within(path, roots):
    parent = os.path.realpath(os.path.dirname(path))
    for r in roots:
        rr = os.path.realpath(r)
        if parent == rr or parent.startswith(rr + os.sep):
            return True
    return False


def delete_tree(path, ctx):
    """Remove a file/folder, leaving behind anything in use or protected.
    Returns how many items were left behind. Symlinks are never followed."""
    skipped = 0
    st = os.lstat(path)
    if not stat.S_ISDIR(st.st_mode):
        if path in ctx.open_set or ctx.is_protected(path):
            return 1
        os.unlink(path)
        return 0
    errs = []
    for dirpath, dirnames, filenames in os.walk(path, topdown=False, followlinks=False,
                                                onerror=errs.append):
        for f in filenames:
            p = os.path.join(dirpath, f)
            if p in ctx.open_set or ctx.is_protected(p):
                skipped += 1
                continue
            try:
                os.unlink(p)
            except FileNotFoundError:
                pass
            except OSError:
                skipped += 1
        for d in dirnames:
            p = os.path.join(dirpath, d)
            if os.path.islink(p):
                if ctx.is_protected(p):
                    skipped += 1
                    continue
                try:
                    os.unlink(p)
                except OSError:
                    skipped += 1
                continue
            if ctx.is_protected(p) or p in ctx.open_set:
                skipped += 1
                continue
            try:
                os.rmdir(p)
            except FileNotFoundError:
                pass
            except OSError as ex:
                if ex.errno != errno.ENOTEMPTY:
                    skipped += 1
    skipped += len(errs)
    try:
        if ctx.is_protected(path):
            skipped += 1
        else:
            os.rmdir(path)
    except OSError:
        pass
    return skipped


def safe_delete(path, roots, ctx=None):
    """Delete `path` only if it lives directly inside an allowed root."""
    path = os.path.abspath(path)
    if not roots or not _within(path, roots):
        raise PermissionError("refused: path is outside the allowed cleanup locations")
    return delete_tree(path, ctx or Ctx())


def _gio_trash(path):
    if not shutil.which("gio"):
        raise RuntimeError(_("Trash support is not available (the 'gio' tool is missing)."))
    _run(["gio", "trash", path], env=dict(os.environ), timeout=300)


def _revalidate(cat, e):
    """Last check right before deleting: is it still what the scan showed?"""
    try:
        st = os.lstat(e.key)
    except FileNotFoundError:
        raise Skipped(_("Already gone."))
    if e.sig and _sig_of(st) != e.sig:
        raise Skipped(_("Changed since the scan - please rescan."))
    if cat.min_age_days:
        _size, newest, special = tree_info(e.key)
        if special or time.time() - max(newest, st.st_ctime) < cat.min_age_days * DAY:
            raise Skipped(_("Used recently - left alone."))
    if cat.id == "browser" and browser_running(e.label):
        raise Skipped(_("%s is running. Close it and rescan.") % e.label.split(" (")[0])


def delete_entry(cat, e, ctx):
    """Remove one entry. Returns (bytes_freed, note). Raises Skipped when it was
    deliberately left alone, other exceptions on real errors."""
    if cat.pkg_manager and not ctx.dry_run and apt_busy():
        raise Skipped(_("The package manager is busy (updates or installs running). "
                        "Wait for it to finish and try again."))

    if cat.id in ("journal", "autoremove", "snaps", "flatpak_user", "flatpak_system", "docker"):
        if ctx.dry_run:
            return e.size, _("Preview - nothing was removed")
        if cat.id == "journal":
            before = _journal_bytes()
            _run(["journalctl", f"--vacuum-time={JOURNAL_KEEP}"])
            return max(0, before - _journal_bytes()), ""
        if cat.id == "autoremove":
            if not e.data:
                raise Skipped(_("Changed since the scan - please rescan."))
            _run(["apt-get", "remove", "-y"] + list(e.data),
                 env=_env({"DEBIAN_FRONTEND": "noninteractive"}))
            return e.size, ""
        if cat.id == "snaps":
            _x, name, rev = e.key.split(":")
            _run(["snap", "remove", name, f"--revision={rev}"])
            return e.size, ""
        if cat.id in ("flatpak_user", "flatpak_system"):
            _run(["flatpak", "uninstall", "--unused", "-y", "--noninteractive", e.data[0]])
            return e.size, ""
        _run(["docker", "system", "prune", "-f"])
        _run(["docker", "builder", "prune", "-f"])
        return e.size, ""

    # ---- path based ----
    if not cat.roots or not _within(os.path.abspath(e.key), cat.roots):
        raise PermissionError("refused: path is outside the allowed cleanup locations")
    _revalidate(cat, e)
    before = tree_info(e.key)[0]
    if ctx.dry_run:
        return before, _("Preview - nothing was removed")
    if ctx.trash and cat.trashable:
        _gio_trash(e.key)
        return 0, _("Moved to Trash")
    skipped = delete_tree(os.path.abspath(e.key), ctx)
    if cat.id == "trash":
        info = os.path.join(HOME, ".local/share/Trash/info", os.path.basename(e.key) + ".trashinfo")
        if os.path.lexists(info) and not os.path.lexists(e.key):
            os.unlink(info)
    after = tree_info(e.key)[0] if os.path.lexists(e.key) else 0
    freed = max(0, before - after)
    note = ""
    if skipped:
        note = _("%d item(s) left alone because they are in use or protected") % skipped
        if freed <= 0:
            raise Skipped(note)
    return freed, note


def _result(cat, e, ok, freed, msg="", skipped=False):
    return {"cat": cat, "key": e, "ok": ok, "skipped": skipped, "freed": freed, "msg": msg}


def do_one(cat, e, ctx):
    try:
        freed, note = delete_entry(cat, e, ctx)
        return _result(cat.id, e.key, True, freed, note)
    except Skipped as ex:
        return _result(cat.id, e.key, True, 0, str(ex), skipped=True)
    except FileNotFoundError:
        return _result(cat.id, e.key, True, 0, _("Already gone."), skipped=True)
    except Exception as ex:
        return _result(cat.id, e.key, False, 0, friendly(ex))


def clean_user(selected, settings=None, progress=None):
    """selected: list of (Category, Entry) with scope == user."""
    s = settings or load_settings()
    CLEAN_CANCEL.clear()
    ctx = Ctx(s["dry_run"], s["trash_user_files"], s["exclusions"])
    results = []
    for i, (cat, e) in enumerate(selected, 1):
        if CLEAN_CANCEL.is_set():
            results.append(_result(cat.id, e.key, True, 0, _("Cancelled."), skipped=True))
            continue
        r = do_one(cat, e, ctx)
        results.append(r)
        if progress:
            progress(i, len(selected), r)
    return results


def clean_root(selected, settings=None, progress=None):
    """Run the system items through the root-owned helper using pkexec."""
    s = settings or load_settings()
    if not os.path.exists(HELPER):
        raise HelperRefused(_("The admin helper is missing. Please install the .deb package."))
    if not shutil.which("pkexec"):
        raise HelperRefused(_("The 'pkexec' tool is missing. Install the 'pkexec' (or policykit-1) package."))
    payload = json.dumps({
        "dry_run": bool(s["dry_run"]),
        "exclusions": s["exclusions"],
        "items": [{"cat": c.id, "key": e.key, "sig": e.sig} for c, e in selected],
    })
    p = subprocess.Popen(["pkexec", HELPER, "--root-clean"], stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    p.stdin.write(payload)
    p.stdin.close()
    results = []
    for line in p.stdout:
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            r = json.loads(line)
        except ValueError:
            continue
        results.append(r)
        if progress:
            progress(len(results), len(selected), r)
    err = p.stderr.read()
    code = p.wait()
    if code in (126, 127) and not results:
        raise AuthCancelled(_("Administrator permission was not granted."))
    if code == 3 and not results:
        raise HelperRefused(err.strip() or _("The admin helper refused to run."))
    if not results and code != 0:
        raise RuntimeError(err.strip() or f"helper exited with code {code}")
    return results


# --------------------------------------------------------------------------
# root helper (started as: pkexec /opt/linux-disk-cleanup/ldc-helper --root-clean)
# --------------------------------------------------------------------------
def helper_install_ok():
    """The helper may only run from a root-owned location that normal users
    cannot modify - otherwise it could be swapped for malicious code."""
    p = os.path.realpath(__file__)
    chain = [p]
    d = os.path.dirname(p)
    while True:
        chain.append(d)
        if d == "/":
            break
        d = os.path.dirname(d)
    for path in chain:
        try:
            st = os.stat(path)
        except OSError:
            return False
        if st.st_uid != 0 or (st.st_mode & 0o022):
            return False
    return True


def _emit(r):
    print(json.dumps(r), flush=True)


def helper_main(strict=True):
    if os.geteuid() != 0:
        print("This mode must run as root.", file=sys.stderr)
        return 2
    if strict and not helper_install_ok():
        print(_("Refusing to run: the helper is not in a root-owned, protected folder. "
                "Install the .deb package to use system cleanup."), file=sys.stderr)
        return 3
    try:
        req = json.load(sys.stdin)
        items = req["items"]
    except (ValueError, KeyError, TypeError):
        print("bad request", file=sys.stderr)
        return 2
    excl = [x for x in req.get("exclusions", []) if isinstance(x, str)]
    ctx = Ctx(bool(req.get("dry_run")), False, excl)
    wanted = {}
    for it in items:
        if isinstance(it, dict) and isinstance(it.get("cat"), str) and isinstance(it.get("key"), str):
            wanted.setdefault(it["cat"], {})[it["key"]] = it.get("sig") or ""
    for cid, keys in wanted.items():
        cat = CAT_BY_ID.get(cid)
        if cat is None or cat.scope != "system":
            for k in keys:
                _emit(_result(cid, k, False, 0, "refused: not a system cleanup category"))
            continue
        current = {e.key: e for e in scan_category(cat) if not is_excluded(e, excl)}
        for k, sig in keys.items():
            e = current.get(k)
            if e is None or (sig and e.sig and sig != e.sig):
                _emit(_result(cid, k, True, 0, _("Changed since the scan - please rescan."),
                              skipped=True))
                continue
            _emit(do_one(cat, e, ctx))
    return 0


# --------------------------------------------------------------------------
# large old files finder (only LISTS - never deletes)
# --------------------------------------------------------------------------
def find_large_files(root, min_bytes, min_age_days, limit=300, progress=None):
    SCAN_CANCEL.clear()
    cutoff = time.time() - min_age_days * DAY
    heap = []
    skip = {os.path.join(root, ".cache"), os.path.join(root, ".local/share/Trash")}
    n = 0
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        if SCAN_CANCEL.is_set():
            break
        dirnames[:] = [d for d in dirnames if os.path.join(dirpath, d) not in skip]
        for f in filenames:
            p = os.path.join(dirpath, f)
            try:
                st = os.lstat(p)
            except OSError:
                continue
            if not stat.S_ISREG(st.st_mode) or st.st_size < min_bytes or st.st_mtime > cutoff:
                continue
            item = (st.st_size, st.st_mtime, p)
            if len(heap) < limit:
                heapq.heappush(heap, item)
            elif item > heap[0]:
                heapq.heapreplace(heap, item)
        n += 1
        if progress and n % 200 == 0:
            progress(dirpath)
    return sorted(heap, reverse=True)


# --------------------------------------------------------------------------
# optional history (off by default; stores counts and sizes, NO file names)
# --------------------------------------------------------------------------
def _history_file():
    return os.path.join(DATA_DIR, "history.jsonl")


def log_history(results, settings):
    if not settings.get("history") or settings.get("dry_run"):
        return
    done = [r for r in results if r.get("ok") and not r.get("skipped")]
    if not results:
        return
    cats = {}
    for r in done:
        c = cats.setdefault(r["cat"], {"n": 0, "freed": 0})
        c["n"] += 1
        c["freed"] += int(r.get("freed", 0))
    rec = {"t": time.strftime("%Y-%m-%d %H:%M"),
           "freed": sum(c["freed"] for c in cats.values()),
           "items": len(done),
           "skipped": sum(1 for r in results if r.get("skipped")),
           "errors": sum(1 for r in results if not r.get("ok")),
           "cats": cats}
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(_history_file(), "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    except OSError:
        pass


def read_history():
    out = []
    try:
        with open(_history_file(), encoding="utf-8") as f:
            for line in f:
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
    except OSError:
        pass
    return out


def clear_history():
    try:
        os.unlink(_history_file())
    except OSError:
        pass


# --------------------------------------------------------------------------
# monthly reminder (a notification only - it never deletes anything)
# --------------------------------------------------------------------------
def _reminder_state():
    return os.path.join(STATE_DIR, "reminder.json")


def remind_check(force=False):
    s = load_settings()
    if not s["reminder"] and not force:
        return 0
    last = 0
    try:
        with open(_reminder_state(), encoding="utf-8") as f:
            last = float(json.load(f).get("last", 0))
    except (OSError, ValueError, TypeError):
        pass
    if not force and time.time() - last < 25 * DAY:
        return 0
    res = scan_all(exclusions=s["exclusions"])
    total = sum(e.size for es in res.entries.values() for e in es)
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(_reminder_state(), "w", encoding="utf-8") as f:
            json.dump({"last": time.time()}, f)
    except OSError:
        pass
    if total >= s["reminder_min_mb"] * 1024 * 1024 and shutil.which("notify-send"):
        subprocess.run(["notify-send", "-a", APP_BRAND, "-i", APP_ID, "Disk Cleanup",
                        _("You can free up to %s. Open Disk Cleanup to review and choose what to "
                          "remove. Nothing is deleted automatically.") % human(total)])
    return 0


def set_reminder_timer(enabled):
    """Turn the monthly systemd user timer on/off. Returns (ok, message)."""
    if not shutil.which("systemctl"):
        return False, _("systemd is not available on this system.")
    action = ["enable", "--now"] if enabled else ["disable", "--now"]
    r = subprocess.run(["systemctl", "--user"] + action + [f"{APP_ID}-reminder.timer"],
                       capture_output=True, text=True)
    return r.returncode == 0, (r.stderr or r.stdout).strip()


# --------------------------------------------------------------------------
# command line
# --------------------------------------------------------------------------
def cli_scan():
    s = load_settings()
    res = scan_all(exclusions=s["exclusions"])
    total = 0
    for c in CATEGORIES:
        es = res.entries.get(c.id, [])
        sz = sum(e.size for e in es)
        total += sz
        tag = "admin" if c.scope == "system" else "user "
        print(f"[{tag}] {c.name:<44} {len(es):>5} items  {human(sz):>10}")
        for e in es[:5]:
            print(f"          {human(e.size):>10}  {e.key}")
    print(f"\nTotal reclaimable: {human(total)}" + (f"  ({res.hidden} hidden by exclusions)" if res.hidden else ""))


def selfcheck():
    ok = True

    def line(name, good, info=""):
        nonlocal ok
        ok = ok and good
        print(f"[{'OK ' if good else 'FAIL'}] {name} {info}")
    distro = ""
    try:
        with open("/etc/os-release") as f:
            distro = re.search(r'PRETTY_NAME="?([^"\n]+)', f.read()).group(1)
    except Exception:
        pass
    print(f"{APP_BRAND} {VERSION} on {distro or 'unknown system'}, Python {sys.version.split()[0]}")
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk  # noqa: F401
        line("GTK 3 (python3-gi)", True)
    except Exception as ex:
        line("GTK 3 (python3-gi)", False, str(ex))
    line("pkexec", bool(shutil.which("pkexec")))
    line("admin helper present", os.path.exists(HELPER), HELPER)
    line("helper location is protected", helper_install_ok(),
         "" if helper_install_ok() else "(install the .deb for system cleanup)")
    line("polkit policy installed", os.path.exists(POLICY_FILE), POLICY_FILE)
    for tool in ("apt-get", "journalctl"):
        line(tool, bool(shutil.which(tool)))
    print("open-programs check:", "precise (wmctrl found)" if shutil.which("wmctrl") and os.environ.get("XDG_SESSION_TYPE") != "wayland"
          else "basic (install wmctrl for window-accurate results)")
    print("optional:", ", ".join(f"{t}={'yes' if shutil.which(t) else 'no'}"
                                 for t in ("gio", "notify-send", "systemctl",
                                           "snap", "flatpak", "docker")))
    return 0 if ok else 1


if __name__ == "__main__":
    if "--root-clean" in sys.argv:
        sys.exit(helper_main(strict=True))
    if "--selfcheck" in sys.argv:
        sys.exit(selfcheck())
    if "--remind-check" in sys.argv:
        sys.exit(remind_check(force="--force" in sys.argv))
    cli_scan()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Disk Cleanup - by SL_Linux : GTK3 front-end (inspired by Windows Disk Cleanup)."""
import functools
import os
import sys
import threading
import time

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib, GObject, Gio, Pango  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
import ldc_core as core  # noqa: E402

_ = core._
APP_NAME = "Disk Cleanup"
APP_BRAND = core.APP_BRAND
APP_VERSION = core.VERSION
ASSETS = os.path.join(os.path.dirname(os.path.realpath(__file__)), "assets")

(COL_CHECK, COL_INCON, COL_NAME, COL_LOC, COL_SIZE, COL_BYTES,
 COL_CAT, COL_KEY, COL_ISCAT, COL_ICON, COL_TIP) = range(11)


def asset_pixbuf(name, size):
    from gi.repository import GdkPixbuf
    for f in (name, "logo-256.png"):          # SVG first, PNG if the SVG loader is missing
        try:
            return GdkPixbuf.Pixbuf.new_from_file_at_size(os.path.join(ASSETS, f), size, size)
        except Exception:
            continue
    return None


def esc(s):
    return GLib.markup_escape_text(str(s))


def open_folder(path):
    folder = path if os.path.isdir(path) else os.path.dirname(path)
    try:
        Gio.AppInfo.launch_default_for_uri(GLib.filename_to_uri(folder, None), None)
    except Exception:
        pass


def guarded(fn):
    """Never fail silently: show any unexpected error in a dialog."""
    @functools.wraps(fn)
    def wrapper(self, *a, **k):
        try:
            return fn(self, *a, **k)
        except Exception as ex:
            self.show_error(str(ex))
    return wrapper


def message(parent, kind, title, text):
    d = Gtk.MessageDialog(transient_for=parent, modal=True, message_type=kind,
                          buttons=Gtk.ButtonsType.OK, text=title)
    d.format_secondary_text(text)
    d.run()
    d.destroy()


# ---------------------------------------------------------------- dialogs
class OptionsDialog(Gtk.Dialog):
    def __init__(self, parent, settings):
        super().__init__(title=_("Options"), transient_for=parent, modal=True)
        self.set_default_size(560, 540)
        self.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        self.add_button(_("Save"), Gtk.ResponseType.OK)
        self.s = dict(settings)
        box = self.get_content_area()
        box.set_spacing(8)
        for side in ("start", "end", "top", "bottom"):
            getattr(box, f"set_margin_{side}")(12)

        def check(text, active, tip=""):
            c = Gtk.CheckButton(label=text)
            c.set_active(active)
            c.get_child().set_line_wrap(True)
            if tip:
                c.set_tooltip_text(tip)
            box.pack_start(c, False, False, 0)
            return c
        self.c_warn = check(_("Warn me to save and close open programs (browsers, terminals, apps) "
                              "before cleaning"), settings["warn_open_apps"],
                            _("Recommended. Cleaning while a program is open can make it misbehave or lose "
                              "unsaved work."))
        self.c_dry = check(_("Preview only - show what would be removed, delete nothing"), settings["dry_run"])
        self.c_trash = check(_("Send my temporary files (/tmp) to the Trash instead of deleting them"),
                             settings["trash_user_files"],
                             _("Only applies to /tmp files. Caches can be rebuilt, and moving them to the "
                               "Trash would not free any space."))
        self.c_hist = check(_("Keep a local cleanup history (sizes and counts only - never file names)"),
                            settings["history"])
        self.c_rem = check(_("Remind me monthly when there is a lot to clean (a notification only - "
                             "nothing is ever deleted automatically)"), settings["reminder"])
        row = Gtk.Box(spacing=6)
        row.pack_start(Gtk.Label(label=_("Remind me when at least")), False, False, 18)
        self.spin = Gtk.SpinButton.new_with_range(100, 100000, 100)
        self.spin.set_value(settings["reminder_min_mb"])
        row.pack_start(self.spin, False, False, 0)
        row.pack_start(Gtk.Label(label=_("MB can be freed")), False, False, 0)
        box.pack_start(row, False, False, 0)

        frame = Gtk.Frame(label=_(" Never clean these (exclusions) "))
        fb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        for side in ("start", "end", "top", "bottom"):
            getattr(fb, f"set_margin_{side}")(8)
        frame.add(fb)
        hint = Gtk.Label(xalign=0, wrap=True)
        hint.set_markup("<small>" + esc(_("A folder keeps itself and everything inside it. A name (for example "
                                          "“firefox”) hides every item that contains that word.")) + "</small>")
        fb.pack_start(hint, False, False, 0)
        self.store = Gtk.ListStore(str)
        for x in settings["exclusions"]:
            self.store.append([x])
        self.tv = Gtk.TreeView(model=self.store)
        self.tv.set_headers_visible(False)
        self.tv.append_column(Gtk.TreeViewColumn("", Gtk.CellRendererText(), text=0))
        sw = Gtk.ScrolledWindow()
        sw.set_shadow_type(Gtk.ShadowType.IN)
        sw.set_min_content_height(120)
        sw.add(self.tv)
        fb.pack_start(sw, True, True, 0)
        bb = Gtk.Box(spacing=6)
        for label, cb in ((_("Add folder…"), self.add_folder), (_("Add name…"), self.add_name),
                          (_("Remove"), self.remove)):
            b = Gtk.Button.new_with_label(label)
            b.connect("clicked", cb)
            bb.pack_start(b, False, False, 0)
        fb.pack_start(bb, False, False, 0)
        box.pack_start(frame, True, True, 0)

        hb = Gtk.Button.new_with_label(_("View cleanup history…"))
        hb.connect("clicked", lambda *_a: HistoryDialog(self).run_and_close())
        box.pack_start(hb, False, False, 0)
        self.show_all()

    def add_folder(self, *_a):
        d = Gtk.FileChooserDialog(title=_("Choose a folder to protect"), transient_for=self,
                                  action=Gtk.FileChooserAction.SELECT_FOLDER)
        d.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Add"), Gtk.ResponseType.OK)
        if d.run() == Gtk.ResponseType.OK and d.get_filename():
            self.store.append([d.get_filename()])
        d.destroy()

    def add_name(self, *_a):
        d = Gtk.Dialog(title=_("Add a name"), transient_for=self, modal=True)
        d.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL, _("Add"), Gtk.ResponseType.OK)
        e = Gtk.Entry()
        e.set_activates_default(True)
        d.set_default_response(Gtk.ResponseType.OK)
        area = d.get_content_area()
        area.set_spacing(6)
        area.pack_start(Gtk.Label(label=_("Items containing this word will never be listed:")), False, False, 6)
        area.pack_start(e, False, False, 6)
        d.show_all()
        if d.run() == Gtk.ResponseType.OK and e.get_text().strip():
            self.store.append([e.get_text().strip()])
        d.destroy()

    def remove(self, *_a):
        model, it = self.tv.get_selection().get_selected()
        if it:
            model.remove(it)

    def values(self):
        s = dict(self.s)
        s.update(warn_open_apps=self.c_warn.get_active(), dry_run=self.c_dry.get_active(), trash_user_files=self.c_trash.get_active(),
                 history=self.c_hist.get_active(), reminder=self.c_rem.get_active(),
                 reminder_min_mb=int(self.spin.get_value()),
                 exclusions=[r[0] for r in self.store])
        return s


class HistoryDialog(Gtk.Dialog):
    def __init__(self, parent):
        super().__init__(title=_("Cleanup history"), transient_for=parent, modal=True)
        self.set_default_size(620, 420)
        self.add_button(_("Close"), Gtk.ResponseType.CLOSE)
        box = self.get_content_area()
        box.set_spacing(8)
        for side in ("start", "end", "top", "bottom"):
            getattr(box, f"set_margin_{side}")(12)
        hist = core.read_history()
        total = sum(h.get("freed", 0) for h in hist)
        head = Gtk.Label(xalign=0, wrap=True)
        if hist:
            head.set_markup(esc(_("Total freed so far:")) + f" <b>{esc(core.human(total))}</b> "
                            + esc(_("in %d cleanup(s)") % len(hist)))
        else:
            head.set_text(_("No history yet. Turn on “Keep a local cleanup history” in Options. "
                            "Only sizes and counts are stored - never file names."))
        box.pack_start(head, False, False, 0)
        store = Gtk.ListStore(str, str, str, str, str)
        for h in reversed(hist):
            store.append([h.get("t", ""), core.human(h.get("freed", 0)), str(h.get("items", 0)),
                          str(h.get("skipped", 0)), str(h.get("errors", 0))])
        tv = Gtk.TreeView(model=store)
        for i, t in enumerate((_("When"), _("Freed"), _("Items"), _("Left alone"), _("Errors"))):
            tv.append_column(Gtk.TreeViewColumn(t, Gtk.CellRendererText(), text=i))
        sw = Gtk.ScrolledWindow()
        sw.set_shadow_type(Gtk.ShadowType.IN)
        sw.add(tv)
        box.pack_start(sw, True, True, 0)
        clear = Gtk.Button.new_with_label(_("Clear history"))
        clear.set_sensitive(bool(hist))
        clear.connect("clicked", self.on_clear, store, head)
        box.pack_start(clear, False, False, 0)
        self.show_all()

    def on_clear(self, btn, store, head):
        core.clear_history()
        store.clear()
        head.set_text(_("History cleared."))
        btn.set_sensitive(False)

    def run_and_close(self):
        self.run()
        self.destroy()


class LargeFilesDialog(Gtk.Dialog):
    """Lists big old files so YOU can decide. Nothing here is ever deleted."""

    def __init__(self, parent):
        super().__init__(title=_("Large old files"), transient_for=parent, modal=True)
        self.set_default_size(820, 520)
        self.add_button(_("Close"), Gtk.ResponseType.CLOSE)
        box = self.get_content_area()
        box.set_spacing(8)
        for side in ("start", "end", "top", "bottom"):
            getattr(box, f"set_margin_{side}")(12)
        note = Gtk.Label(xalign=0, wrap=True)
        note.set_text(_("Finds big files in your home folder that you have not changed for a long time. "
                        "This list is only for your information - Disk Cleanup never deletes these files. "
                        "Double-click a row to open its folder."))
        box.pack_start(note, False, False, 0)
        bar = Gtk.Box(spacing=6)
        bar.pack_start(Gtk.Label(label=_("Bigger than")), False, False, 0)
        self.size = Gtk.SpinButton.new_with_range(10, 100000, 50)
        self.size.set_value(500)
        bar.pack_start(self.size, False, False, 0)
        bar.pack_start(Gtk.Label(label=_("MB and not changed for")), False, False, 0)
        self.age = Gtk.SpinButton.new_with_range(0, 3650, 30)
        self.age.set_value(180)
        bar.pack_start(self.age, False, False, 0)
        bar.pack_start(Gtk.Label(label=_("days")), False, False, 0)
        self.go = Gtk.Button.new_with_label(_("Search"))
        self.go.connect("clicked", self.start)
        self.stop = Gtk.Button.new_with_label(_("Stop"))
        self.stop.set_sensitive(False)
        self.stop.connect("clicked", lambda *_a: core.request_cancel())
        bar.pack_end(self.stop, False, False, 0)
        bar.pack_end(self.go, False, False, 0)
        box.pack_start(bar, False, False, 0)
        self.store = Gtk.ListStore(str, str, str, GObject.TYPE_INT64)
        tv = Gtk.TreeView(model=self.store)
        for i, t in enumerate((_("Size"), _("Last changed"), _("File"))):
            r = Gtk.CellRendererText()
            if i == 0:
                r.set_property("xalign", 1.0)
            if i == 2:
                r.set_property("ellipsize", Pango.EllipsizeMode.MIDDLE)
            c = Gtk.TreeViewColumn(t, r, text=i)
            c.set_expand(i == 2)
            tv.append_column(c)
        tv.connect("row-activated", lambda t, p, c: open_folder(self.store[p][2]))
        sw = Gtk.ScrolledWindow()
        sw.set_shadow_type(Gtk.ShadowType.IN)
        sw.add(tv)
        box.pack_start(sw, True, True, 0)
        self.status = Gtk.Label(xalign=0)
        box.pack_start(self.status, False, False, 0)
        self.show_all()

    def start(self, *_a):
        self.store.clear()
        self.go.set_sensitive(False)
        self.stop.set_sensitive(True)
        self.status.set_text(_("Searching…"))
        mb, days = int(self.size.get_value()), int(self.age.get_value())
        threading.Thread(target=self.worker, args=(mb, days), daemon=True).start()

    def worker(self, mb, days):
        found = core.find_large_files(core.HOME, mb * 1024 * 1024, days)
        GLib.idle_add(self.done, found)

    def done(self, found):
        for size, mtime, path in found:
            self.store.append([core.human(size), time.strftime("%Y-%m-%d", time.localtime(mtime)), path, size])
        self.status.set_text(_("%d file(s) found.") % len(found) if found else _("Nothing found."))
        self.go.set_sensitive(True)
        self.stop.set_sensitive(False)
        return False


class OpenAppsDialog(Gtk.Dialog):
    """Asks the user to save their work and close open programs first."""
    KIND_ICON = {"browser": "web-browser", "terminal": "utilities-terminal",
                 "app": "application-x-executable"}

    def __init__(self, parent, apps):
        super().__init__(title=_("Save your work first"), transient_for=parent, modal=True)
        self.set_default_size(520, 420)
        self.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        go = self.add_button(_("Continue anyway"), Gtk.ResponseType.ACCEPT)
        go.set_tooltip_text(_("Not recommended: unsaved work in these programs could be lost."))
        again = self.add_button(_("I closed them - check again"), Gtk.ResponseType.APPLY)
        again.get_style_context().add_class("suggested-action")
        self.set_default_response(Gtk.ResponseType.APPLY)
        box = self.get_content_area()
        box.set_spacing(8)
        for side in ("start", "end", "top", "bottom"):
            getattr(box, f"set_margin_{side}")(12)
        head = Gtk.Label(xalign=0, wrap=True)
        head.set_markup("<b>" + esc(_("These programs are open right now:")) + "</b>\n" + esc(
            _("Cleaning while they run can make them misbehave, and anything you have not saved "
              "could be lost. Please save your work and close them, then press “I closed them - "
              "check again”.")))
        box.pack_start(head, False, False, 0)
        store = Gtk.ListStore(str, str, str)
        labels = {"browser": _("Web browser"), "terminal": _("Terminal"), "app": _("Application")}
        for a in apps:
            name = a["name"] + (f"  ×{a['count']}" if a["count"] > 1 and a["kind"] != "app" else "")
            store.append([self.KIND_ICON.get(a["kind"], "application-x-executable"), name,
                          labels.get(a["kind"], "")])
        tv = Gtk.TreeView(model=store)
        tv.set_headers_visible(False)
        tv.get_selection().set_mode(Gtk.SelectionMode.NONE)
        col = Gtk.TreeViewColumn()
        ic = Gtk.CellRendererPixbuf()
        col.pack_start(ic, False)
        col.add_attribute(ic, "icon-name", 0)
        txt = Gtk.CellRendererText()
        col.pack_start(txt, True)
        col.add_attribute(txt, "text", 1)
        col.set_expand(True)
        tv.append_column(col)
        kind = Gtk.CellRendererText()
        kind.set_property("xalign", 1.0)
        tv.append_column(Gtk.TreeViewColumn("", kind, text=2))
        sw = Gtk.ScrolledWindow()
        sw.set_shadow_type(Gtk.ShadowType.IN)
        sw.add(tv)
        box.pack_start(sw, True, True, 0)
        tip = Gtk.Label(xalign=0, wrap=True)
        tip.set_markup("<small>" + esc(_("Tip: your terminal windows and any unsaved documents are the most "
                                         "important to check.")) + "</small>")
        box.pack_start(tip, False, False, 0)
        self.show_all()


# ---------------------------------------------------------------- main window
class CleanerWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title=APP_BRAND)
        self.set_default_size(920, 700)
        pb = asset_pixbuf("linux-disk-cleanup.svg", 128)
        if pb:
            self.set_icon(pb)
        else:
            self.set_icon_name("linux-disk-cleanup")
        self.settings = core.load_settings()
        self.entries = {}       # (cat_id, key) -> core.Entry
        self.busy = False
        self.accel = Gtk.AccelGroup()
        self.add_accel_group(self.accel)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        for side in ("start", "end", "top", "bottom"):
            getattr(root, f"set_margin_{side}")(12)
        self.add(root)

        head = Gtk.Box(spacing=12)
        logo = asset_pixbuf("linux-disk-cleanup.svg", 56)
        if logo:
            head.pack_start(Gtk.Image.new_from_pixbuf(logo), False, False, 0)
        names = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        title = Gtk.Label(xalign=0)
        title.set_markup("<span size='x-large' weight='bold'>Disk Cleanup</span>")
        by = Gtk.Label(xalign=0)
        by.set_markup("<span alpha='70%'>by SL_Linux</span>")
        names.pack_start(title, False, False, 0)
        names.pack_start(by, False, False, 0)
        head.pack_start(names, True, True, 0)
        for label, cb, tip in ((_("About"), self.on_about, "F1"),
                               (_("Options"), self.on_options, "Ctrl+,"),
                               (_("Large files"), self.on_large, "")):
            b = Gtk.Button.new_with_label(label)
            b.set_valign(Gtk.Align.CENTER)
            b.connect("clicked", cb)
            if tip:
                b.set_tooltip_text(tip)
            head.pack_end(b, False, False, 0)
            if label == _("About"):
                self.btn_about = b
            elif label == _("Options"):
                self.btn_opts = b
        root.pack_start(head, False, False, 0)

        sub = Gtk.Label(xalign=0, wrap=True)
        sub.set_text(_("Tick the items you want to delete, then press “Clean up”. Only caches, temporary "
                       "files and old logs are listed. Expand an item to see every location and its size."))
        root.pack_start(sub, False, False, 0)

        # ---- tree ----
        self.store = Gtk.TreeStore(bool, bool, str, str, str, GObject.TYPE_INT64,
                                   str, str, bool, str, str)
        self.tree = Gtk.TreeView(model=self.store)
        self.tree.set_tooltip_column(COL_TIP)
        self.tree.set_enable_tree_lines(True)
        self.tree.connect("row-activated", self.on_row_activated)

        tog = Gtk.CellRendererToggle()
        tog.connect("toggled", self.on_toggled)
        self.tree.append_column(Gtk.TreeViewColumn("", tog, active=COL_CHECK, inconsistent=COL_INCON))

        txt = Gtk.CellRendererText()
        txt.set_property("ellipsize", Pango.EllipsizeMode.END)
        icon = Gtk.CellRendererPixbuf()
        col = Gtk.TreeViewColumn(_("What to delete"))
        col.pack_start(txt, True)
        col.pack_start(icon, False)
        col.add_attribute(txt, "markup", COL_NAME)
        col.add_attribute(icon, "icon-name", COL_ICON)
        col.set_expand(True)
        col.set_resizable(True)
        col.set_min_width(330)
        self.tree.append_column(col)

        loc = Gtk.CellRendererText()
        loc.set_property("ellipsize", Pango.EllipsizeMode.MIDDLE)
        col = Gtk.TreeViewColumn(_("Location"), loc, text=COL_LOC)
        col.set_expand(True)
        col.set_resizable(True)
        col.set_min_width(220)
        self.tree.append_column(col)

        sz = Gtk.CellRendererText()
        sz.set_property("xalign", 1.0)
        col = Gtk.TreeViewColumn(_("Size"), sz, text=COL_SIZE)
        col.set_min_width(90)
        self.tree.append_column(col)

        sw = Gtk.ScrolledWindow()
        sw.set_shadow_type(Gtk.ShadowType.IN)
        sw.add(self.tree)
        root.pack_start(sw, True, True, 0)

        # ---- status ----
        self.total_label = Gtk.Label(xalign=0)
        root.pack_start(self.total_label, False, False, 0)
        self.mode_label = Gtk.Label(xalign=0)
        root.pack_start(self.mode_label, False, False, 0)
        self.progress = Gtk.ProgressBar()
        self.progress.set_no_show_all(True)
        root.pack_start(self.progress, False, False, 0)
        self.status = Gtk.Label(xalign=0)
        self.status.get_style_context().add_class("dim-label")
        root.pack_start(self.status, False, False, 0)

        # ---- buttons ----
        bar = Gtk.Box(spacing=6)

        def mk(label, cb, key=None, mods=Gtk.AccelFlags.VISIBLE and Gdk.ModifierType.CONTROL_MASK, tip=""):
            b = Gtk.Button.new_with_label(label)
            b.connect("clicked", cb)
            if key:
                b.add_accelerator("clicked", self.accel, key, mods, Gtk.AccelFlags.VISIBLE)
            if tip:
                b.set_tooltip_text(tip)
            return b
        ctrl, shift = Gdk.ModifierType.CONTROL_MASK, Gdk.ModifierType.SHIFT_MASK
        self.btn_rescan = mk(_("Rescan"), lambda *_a: self.start_scan(), Gdk.KEY_r, ctrl, "Ctrl+R")
        self.btn_all = mk(_("Select all"), lambda *_a: self.select_all(True), Gdk.KEY_a, ctrl, "Ctrl+A")
        self.btn_none = mk(_("Select none"), lambda *_a: self.select_all(False), Gdk.KEY_a, ctrl | shift, "Ctrl+Shift+A")
        self.btn_rec = mk(_("Recommended"), lambda *_a: self.select_recommended(), tip=_("Tick the safe, everyday items"))
        self.btn_clean = mk(_("Clean up…"), self.on_clean, Gdk.KEY_Return, ctrl, "Ctrl+Enter")
        self.btn_clean.get_style_context().add_class("suggested-action")
        self.btn_cancel = Gtk.Button.new_with_label(_("Cancel"))
        self.btn_cancel.connect("clicked", self.on_cancel)
        self.btn_cancel.add_accelerator("clicked", self.accel, Gdk.KEY_Escape, 0, Gtk.AccelFlags.VISIBLE)
        self.btn_cancel.set_no_show_all(True)
        self.btn_about.add_accelerator("clicked", self.accel, Gdk.KEY_F1, 0, Gtk.AccelFlags.VISIBLE)
        self.btn_opts.add_accelerator("clicked", self.accel, Gdk.KEY_comma, ctrl, Gtk.AccelFlags.VISIBLE)
        for b in (self.btn_rescan, self.btn_all, self.btn_none, self.btn_rec):
            bar.pack_start(b, False, False, 0)
        bar.pack_end(self.btn_clean, False, False, 0)
        bar.pack_end(self.btn_cancel, False, False, 0)
        root.pack_start(bar, False, False, 0)

        note = Gtk.Label(xalign=0, wrap=True)
        note.set_markup("<small>" + esc(_("Deleted files are removed permanently (they do not go to the Trash). "
                                          "Items marked with a lock need your administrator password. "
                                          "Files in use and your exclusions are always left alone. "
                                          "No password is ever stored.")) + "</small>")
        root.pack_start(note, False, False, 0)

        self.connect("key-press-event", self.on_key)
        self.show_all()
        self.progress.hide()
        self.btn_cancel.hide()
        self.refresh_mode()
        self.start_scan()

    # ------------------------------------------------------------ small helpers
    def on_key(self, _w, ev):
        return False

    def show_error(self, text):
        message(self, Gtk.MessageType.ERROR, _("Something went wrong"), text)

    def refresh_mode(self):
        if self.settings["dry_run"]:
            self.mode_label.set_markup("<b>" + esc(_("Preview mode is ON - nothing will be deleted. "
                                                      "Change this in Options.")) + "</b>")
            self.btn_clean.set_label(_("Preview…"))
        else:
            self.mode_label.set_text("")
            self.btn_clean.set_label(_("Clean up…"))

    def on_about(self, *_a):
        dlg = Gtk.AboutDialog(transient_for=self, modal=True)
        dlg.set_program_name(APP_BRAND)
        dlg.set_version(APP_VERSION)
        dlg.set_comments(_("Free disk space by removing temporary files, caches and old logs "
                           "- safely, with a preview of every location and size."))
        dlg.set_copyright("© SL_Linux")
        dlg.set_authors(["SL_Linux"])
        logo = asset_pixbuf("linux-disk-cleanup.svg", 128)
        if logo:
            dlg.set_logo(logo)
        dlg.run()
        dlg.destroy()

    @guarded
    def on_options(self, *_a):
        if self.busy:
            return
        dlg = OptionsDialog(self, self.settings)
        resp = dlg.run()
        new = dlg.values() if resp == Gtk.ResponseType.OK else None
        dlg.destroy()
        if new is None:
            return
        old = self.settings
        core.save_settings(new)
        self.settings = core.load_settings()
        if new["reminder"] != old["reminder"]:
            ok, msg = core.set_reminder_timer(new["reminder"])
            if not ok:
                message(self, Gtk.MessageType.WARNING, _("Monthly reminder"),
                        _("Could not change the reminder schedule.") + "\n\n" + msg)
        self.refresh_mode()
        if new["exclusions"] != old["exclusions"]:
            self.start_scan()
        else:
            self.update_total()

    @guarded
    def on_large(self, *_a):
        if self.busy:
            return
        dlg = LargeFilesDialog(self)
        dlg.run()
        core.SCAN_CANCEL.set()
        dlg.destroy()

    def on_cancel(self, *_a):
        core.request_cancel()
        self.status.set_text(_("Cancelling…"))

    # ------------------------------------------------------------------ busy
    def set_busy(self, busy, text="", cancellable=False):
        self.busy = busy
        for b in (self.btn_rescan, self.btn_all, self.btn_none, self.btn_rec, self.btn_clean):
            b.set_sensitive(not busy)
        self.tree.set_sensitive(not busy)
        self.status.set_text(text)
        self.btn_cancel.set_sensitive(cancellable)
        if busy:
            self.progress.show()
            self.btn_cancel.show()
            GLib.timeout_add(120, self._pulse)
        else:
            self.progress.hide()
            self.btn_cancel.hide()
            self.update_total()

    def _pulse(self):
        if self.busy:
            self.progress.pulse()
            return True
        return False

    def _status(self, text):
        GLib.idle_add(self.status.set_text, text)

    # ------------------------------------------------------------------ scan
    def start_scan(self):
        if self.busy:
            return
        self.set_busy(True, _("Scanning your system… this can take a few seconds."), cancellable=True)
        threading.Thread(target=self._scan_worker, daemon=True).start()

    def _scan_worker(self):
        def prog(done, total, cat):
            self._status(_("Scanning… %(done)d of %(total)d - %(name)s") %
                         {"done": done, "total": total, "name": cat.name})
        try:
            res = core.scan_all(prog, self.settings["exclusions"])
        except Exception as ex:
            GLib.idle_add(self._scan_failed, str(ex))
            return
        GLib.idle_add(self._scan_done, res)

    def _scan_failed(self, text):
        self.set_busy(False, "")
        self.show_error(text)
        return False

    def _scan_done(self, res):
        self.store.clear()
        self.entries.clear()
        grand = 0
        for cat in core.CATEGORIES:
            es = res.entries.get(cat.id, [])
            total = sum(e.size for e in es)
            grand += total
            name = f"<b>{esc(cat.name)}</b>"
            if cat.advanced:
                name += "  <small><i>" + esc(_("Advanced")) + "</i></small>"
            markup = f"{name}\n<small>{esc(cat.desc)}</small>"
            tip = esc(cat.desc)
            icon = ""
            if cat.scope == "system":
                icon = "dialog-password-symbolic"
                tip += "\n<i>" + esc(_("Needs administrator permission to delete.")) + "</i>"
            if cat.advanced:
                tip += "\n<i>" + esc(_("Advanced: you must confirm that you reviewed these items.")) + "</i>"
            approx = any(e.approx for e in es)
            size_txt = (("≤ " if approx else "") + core.human(total)) if es else "—"
            parent = self.store.append(None, [False, False, markup, cat.where, size_txt, total,
                                              cat.id, "", True, icon, tip])
            for e in es:
                self.entries[(cat.id, e.key)] = e
                path_like = e.key.startswith("/")
                label = esc(e.label)
                if e.warn:
                    label += "  <i>(" + esc(e.warn) + ")</i>"
                tip_c = esc(e.key if path_like else e.label)
                if e.detail:
                    tip_c += "\n\n" + esc(e.detail)
                self.store.append(parent, [
                    cat.default and not e.warn, False, label,
                    e.key if path_like else e.location,
                    ("≤ " if e.approx else "") + core.human(e.size), e.size,
                    cat.id, e.key, False, "", tip_c])
            if es:
                self.refresh_parent(parent)
        text = _("Scan complete - up to %s can be cleaned.") % core.human(grand)
        if res.cancelled:
            text = _("Scan cancelled - the list below is incomplete.")
        if res.hidden:
            text += "  " + _("%d item(s) hidden by your exclusions.") % res.hidden
        self.set_busy(False, text)
        return False

    # ------------------------------------------------------------- selection
    def on_toggled(self, _renderer, path):
        it = self.store.get_iter(path)
        row = self.store[it]
        self.set_checked(it, True if row[COL_INCON] else (not row[COL_CHECK]))
        self.update_total()

    def set_checked(self, it, value):
        store = self.store
        if store[it][COL_ISCAT]:
            store[it][COL_CHECK] = value
            store[it][COL_INCON] = False
            child = store.iter_children(it)
            while child:
                store[child][COL_CHECK] = value
                child = store.iter_next(child)
        else:
            store[it][COL_CHECK] = value
            self.refresh_parent(store.iter_parent(it))

    def refresh_parent(self, parent):
        store = self.store
        n = c = 0
        child = store.iter_children(parent)
        while child:
            n += 1
            c += 1 if store[child][COL_CHECK] else 0
            child = store.iter_next(child)
        store[parent][COL_CHECK] = n > 0 and c == n
        store[parent][COL_INCON] = 0 < c < n

    def select_all(self, value):
        it = self.store.get_iter_first()
        while it:
            if self.store.iter_n_children(it) > 0:
                self.set_checked(it, value)
            it = self.store.iter_next(it)
        self.update_total()

    def select_recommended(self):
        it = self.store.get_iter_first()
        while it:
            cat = core.CAT_BY_ID[self.store[it][COL_CAT]]
            child = self.store.iter_children(it)
            while child:
                e = self.entries.get((cat.id, self.store[child][COL_KEY]))
                self.store[child][COL_CHECK] = bool(cat.default and e and not e.warn)
                child = self.store.iter_next(child)
            if self.store.iter_n_children(it) > 0:
                self.refresh_parent(it)
            it = self.store.iter_next(it)
        self.update_total()

    def selected(self):
        out = []
        it = self.store.get_iter_first()
        while it:
            child = self.store.iter_children(it)
            while child:
                row = self.store[child]
                if row[COL_CHECK]:
                    e = self.entries.get((row[COL_CAT], row[COL_KEY]))
                    if e:
                        out.append((core.CAT_BY_ID[row[COL_CAT]], e))
                child = self.store.iter_next(child)
            it = self.store.iter_next(it)
        return out

    def update_total(self):
        sel = self.selected()
        total = sum(e.size for _c, e in sel)
        approx = any(e.approx for _c, e in sel)
        if sel:
            self.total_label.set_markup(
                "<b>" + esc(_("Selected:")) + "</b> " + esc(_("%d item(s) - you can free up to") % len(sel))
                + f" <b>{esc(core.human(total))}</b>" + (" " + esc(_("(estimate)")) if approx else ""))
        else:
            self.total_label.set_markup("<b>" + esc(_("Nothing selected")) + "</b>")
        self.btn_clean.set_sensitive(bool(sel) and not self.busy)

    def on_row_activated(self, tree, path, _col):
        row = self.store[self.store.get_iter(path)]
        if row[COL_ISCAT]:
            if tree.row_expanded(path):
                tree.collapse_row(path)
            else:
                tree.expand_row(path, False)
        elif row[COL_KEY].startswith("/"):
            open_folder(row[COL_KEY])

    # ----------------------------------------------------------------- clean
    def confirm(self, sel):
        total = sum(e.size for _c, e in sel)
        needs_admin = any(c.scope == "system" for c, _e in sel)
        has_adv = any(c.advanced for c, _e in sel)
        dry = self.settings["dry_run"]

        dlg = Gtk.Dialog(title=_("Preview") if dry else _("Confirm cleanup"), transient_for=self, modal=True)
        dlg.set_default_size(580, 460)
        dlg.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        ok = dlg.add_button(_("Run preview") if dry else _("Delete permanently"), Gtk.ResponseType.OK)
        if not dry:
            ok.get_style_context().add_class("destructive-action")
        dlg.set_default_response(Gtk.ResponseType.CANCEL)
        box = dlg.get_content_area()
        box.set_spacing(8)
        for side in ("start", "end", "top", "bottom"):
            getattr(box, f"set_margin_{side}")(12)

        head = Gtk.Label(xalign=0, wrap=True)
        if dry:
            msg = "<b>" + esc(_("Preview %(n)d item(s) (up to %(size)s)?") %
                              {"n": len(sel), "size": core.human(total)}) + "</b>\n" + \
                  esc(_("Nothing will be deleted."))
        else:
            msg = "<b>" + esc(_("Permanently delete %(n)d item(s) (up to %(size)s)?") %
                              {"n": len(sel), "size": core.human(total)}) + "</b>\n" + \
                  esc(_("This cannot be undone. Files in use are left alone."))
        if needs_admin:
            msg += "\n\n" + esc(_("Some items are system files. After you confirm, you will be asked "
                                  "for your administrator password."))
        head.set_markup(msg)
        box.pack_start(head, False, False, 0)

        by_cat, cats = {}, {}
        for c, e in sel:
            by_cat.setdefault(c.id, []).append(e)
            cats[c.id] = c
        lines = []
        for cid, es in by_cat.items():
            c = cats[cid]
            lines.append(f"• {c.name}: {len(es)} item(s), {core.human(sum(x.size for x in es))}"
                         + ("  [admin]" if c.scope == "system" else "")
                         + ("  [advanced]" if c.advanced else ""))
            if c.advanced:
                for e in es:
                    if e.detail:
                        lines.append("    " + e.detail.replace("\n", "\n    "))
        tv = Gtk.TextView(editable=False, cursor_visible=False, wrap_mode=Gtk.WrapMode.WORD)
        tv.get_buffer().set_text("\n".join(lines))
        sw = Gtk.ScrolledWindow()
        sw.set_shadow_type(Gtk.ShadowType.IN)
        sw.set_min_content_height(200)
        sw.add(tv)
        box.pack_start(sw, True, True, 0)

        if has_adv and not dry:
            ack = Gtk.CheckButton(label=_("I have reviewed the advanced items above and understand that "
                                          "they remove installed software or system data."))
            ack.get_child().set_line_wrap(True)
            ok.set_sensitive(False)
            ack.connect("toggled", lambda b: ok.set_sensitive(b.get_active()))
            box.pack_start(ack, False, False, 0)
        dlg.show_all()
        resp = dlg.run()
        dlg.destroy()
        return resp == Gtk.ResponseType.OK

    def ensure_apps_closed(self):
        """Before anything is deleted: ask the user to save work and close open
        programs. Loops until nothing is open, or the user chooses to go on."""
        if not self.settings["warn_open_apps"] or self.settings["dry_run"]:
            return True
        while True:
            apps = core.detect_open_apps()
            if not apps:
                return True
            dlg = OpenAppsDialog(self, apps)
            resp = dlg.run()
            dlg.destroy()
            if resp == Gtk.ResponseType.APPLY:
                continue
            return resp == Gtk.ResponseType.ACCEPT

    @guarded
    def on_clean(self, *_a):
        sel = self.selected()
        if not sel:
            return
        if not self.settings["dry_run"] and any(c.pkg_manager for c, _e in sel) \
                and (core.APT_PROCS & core.running_names()):
            message(self, Gtk.MessageType.INFO, _("Package manager is busy"),
                    _("Software updates or installs are running right now. Wait for them to finish, "
                      "then try again."))
            return
        if not self.ensure_apps_closed():
            return
        if not self.confirm(sel):
            return
        self.set_busy(True, _("Cleaning…"), cancellable=True)
        threading.Thread(target=self._clean_worker, args=(sel, dict(self.settings)), daemon=True).start()

    def _clean_worker(self, sel, settings):
        results, notes = [], []
        try:
            user_sel = [(c, e) for c, e in sel if c.scope == "user"]
            sys_sel = [(c, e) for c, e in sel if c.scope == "system"]
            if user_sel:
                results += core.clean_user(
                    user_sel, settings,
                    lambda i, n, r: self._status(_("Cleaning your files… %(i)d/%(n)d") % {"i": i, "n": n}))
            if sys_sel:
                GLib.idle_add(self.btn_cancel.set_sensitive, False)
                self._status(_("Waiting for administrator permission…"))
                try:
                    results += core.clean_root(
                        sys_sel, settings,
                        lambda i, n, r: self._status(_("Cleaning system files… %(i)d/%(n)d") % {"i": i, "n": n}))
                except core.AuthCancelled:
                    notes.append(_("Administrator permission was cancelled - system items were skipped."))
                except core.HelperRefused as ex:
                    notes.append(_("System cleanup was not started: %s") % ex)
                except Exception as ex:
                    notes.append(_("System cleanup failed: %s") % core.friendly(ex))
            core.log_history(results, settings)
        except Exception as ex:
            notes.append(_("Unexpected error: %s") % ex)
        GLib.idle_add(self._clean_done, results, notes, settings["dry_run"])

    def _clean_done(self, results, notes, dry):
        done = [r for r in results if r["ok"] and not r["skipped"]]
        skipped = [r for r in results if r["skipped"]]
        bad = [r for r in results if not r["ok"]]
        freed = sum(r["freed"] for r in done)
        if dry:
            text = _("Preview finished: %(n)d item(s) would be removed, freeing about %(size)s. "
                     "Nothing was deleted.") % {"n": len(done), "size": core.human(freed)}
        else:
            text = _("%(n)d item(s) removed - %(size)s freed.") % {"n": len(done), "size": core.human(freed)}
            partial = sum(1 for r in done if r["msg"])
            if partial:
                text += "\n" + _("%d of them had some files left alone because they were in use.") % partial
        if skipped:
            text += "\n\n" + _("%d item(s) were left alone:") % len(skipped)
            for r in skipped[:6]:
                text += f"\n• {os.path.basename(r['key'].rstrip('/')) or r['key']}: {r['msg']}"
            if len(skipped) > 6:
                text += "\n" + _("… and %d more") % (len(skipped) - 6)
        if bad:
            text += "\n\n" + _("%d item(s) could not be removed:") % len(bad)
            for r in bad[:6]:
                text += f"\n• {os.path.basename(r['key'].rstrip('/')) or r['key']}: {r['msg']}"
            if len(bad) > 6:
                text += "\n" + _("… and %d more") % (len(bad) - 6)
        for n in notes:
            text += "\n\n" + n
        self.busy = False
        message(self, Gtk.MessageType.WARNING if (bad or notes) else Gtk.MessageType.INFO,
                _("Preview finished") if dry else _("Cleanup finished"), text)
        self.set_busy(False)
        if not dry:
            self.start_scan()
        return False


def main():
    if "--remind-check" in sys.argv:
        sys.exit(core.remind_check(force="--force" in sys.argv))
    if "--selfcheck" in sys.argv:
        sys.exit(core.selfcheck())
    if "--version" in sys.argv:
        print(f"{APP_BRAND} {APP_VERSION}")
        return
    win = CleanerWindow()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()

"""Safety tests for Disk Cleanup - by SL_Linux.   Run:  python3 -m unittest discover -s tests -v"""
import importlib
import json
import os
import sys
import tempfile
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import ldc_core as core  # noqa: E402


def write(path, n=1000, age_days=0):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"x" * n)
    if age_days:
        t = time.time() - age_days * 86400
        os.utime(path, (t, t))
    return path


class Base(unittest.TestCase):
    def setUp(self):
        self.home = tempfile.mkdtemp(prefix="ldc-test-")
        self._old = {k: os.environ.get(k) for k in ("HOME", "XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME")}
        os.environ["HOME"] = self.home
        for k in ("XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME"):
            os.environ.pop(k, None)
        importlib.reload(core)
        self.core = core

    def tearDown(self):
        for k, v in self._old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        importlib.reload(core)

    def entry(self, cat_id, path):
        cat = core.CAT_BY_ID[cat_id]
        es = [e for e in cat.enum() if e.key == path]
        self.assertTrue(es, f"{path} not found by scan")
        return cat, es[0]


class DeleteSafety(Base):
    def test_refuses_outside_allowed_roots(self):
        with self.assertRaises(PermissionError):
            core.safe_delete("/etc/hostname", core.CAT_BY_ID["user_cache"].roots)

    def test_refuses_when_no_roots(self):
        with self.assertRaises(PermissionError):
            core.safe_delete(os.path.join(self.home, "x"), [])

    def test_symlink_is_not_followed(self):
        outside = write(os.path.join(self.home, "outside", "keep.txt"))
        write(os.path.join(self.home, ".cache/foo/blob"), 5000)
        os.symlink(os.path.dirname(outside), os.path.join(self.home, ".cache/foo/link"))
        cat, e = self.entry("user_cache", os.path.join(self.home, ".cache/foo"))
        r = core.do_one(cat, e, core.Ctx())
        self.assertTrue(r["ok"], r)
        self.assertFalse(os.path.exists(e.key))
        self.assertTrue(os.path.exists(outside), "symlink target must survive")

    def test_open_file_is_left_alone(self):
        p = write(os.path.join(self.home, ".cache/app/live.db"), 5000)
        write(os.path.join(self.home, ".cache/app/old.bin"), 5000)
        cat, e = self.entry("user_cache", os.path.join(self.home, ".cache/app"))
        with open(p, "rb"):
            r = core.do_one(cat, e, core.Ctx())
        self.assertTrue(r["ok"], r)
        self.assertTrue(os.path.exists(p), "open file must not be deleted")
        self.assertFalse(os.path.exists(os.path.join(self.home, ".cache/app/old.bin")))
        self.assertIn("left alone", r["msg"])

    def test_only_open_files_means_skipped(self):
        p = write(os.path.join(self.home, ".cache/solo/live.db"), 5000)
        cat, e = self.entry("user_cache", os.path.join(self.home, ".cache/solo"))
        with open(p, "rb"):
            r = core.do_one(cat, e, core.Ctx())
        self.assertTrue(r["skipped"], r)
        self.assertTrue(os.path.exists(p))

    def test_excluded_folder_survives(self):
        keep = write(os.path.join(self.home, ".cache/proj/keepme/data"), 3000)
        write(os.path.join(self.home, ".cache/proj/junk"), 3000)
        cat, e = self.entry("user_cache", os.path.join(self.home, ".cache/proj"))
        ctx = core.Ctx(protected=[os.path.dirname(keep)])
        r = core.do_one(cat, e, ctx)
        self.assertTrue(os.path.exists(keep))
        self.assertFalse(os.path.exists(os.path.join(self.home, ".cache/proj/junk")))
        self.assertTrue(r["ok"])

    def test_dry_run_deletes_nothing(self):
        p = write(os.path.join(self.home, ".cache/dry/a"), 8000)
        cat, e = self.entry("user_cache", os.path.join(self.home, ".cache/dry"))
        r = core.do_one(cat, e, core.Ctx(dry_run=True))
        self.assertTrue(r["ok"] and r["freed"] > 0, r)
        self.assertTrue(os.path.exists(p))

    def test_changed_item_is_skipped(self):
        d = os.path.join(self.home, ".cache/swap")
        write(os.path.join(d, "a"), 3000)
        cat, e = self.entry("user_cache", d)
        os.rename(d, d + ".moved")          # keeps the old inode alive...
        os.makedirs(d)                      # ...so the new folder gets a different one
        write(os.path.join(d, "precious"), 3000)
        r = core.do_one(cat, e, core.Ctx())
        self.assertTrue(r["skipped"], r)
        self.assertTrue(os.path.exists(os.path.join(d, "precious")))

    def test_recently_used_tmp_is_skipped(self):
        p = write("/tmp/ldc-unit-old.bin", 4000, age_days=5)
        try:
            os.utime(p, (time.time() - 5 * 86400,) * 2)
            st = os.lstat(p)
            e = core.Entry("user_tmp", p, "ldc-unit-old.bin", "/tmp", 4096, sig=core._sig_of(st))
            os.utime(p, None)               # touched "now" after the scan
            r = core.do_one(core.CAT_BY_ID["user_tmp"], e, core.Ctx())
            self.assertTrue(r["skipped"], r)
            self.assertTrue(os.path.exists(p))
        finally:
            if os.path.exists(p):
                os.unlink(p)

    def test_trash_info_removed_too(self):
        write(os.path.join(self.home, ".local/share/Trash/files/old.txt"), 3000)
        info = write(os.path.join(self.home, ".local/share/Trash/info/old.txt.trashinfo"), 20)
        cat, e = self.entry("trash", os.path.join(self.home, ".local/share/Trash/files/old.txt"))
        r = core.do_one(cat, e, core.Ctx())
        self.assertTrue(r["ok"], r)
        self.assertFalse(os.path.exists(info))


class Exclusions(Base):
    def test_matching(self):
        e = core.Entry("browser", f"{self.home}/.cache/mozilla/firefox", "Firefox", "x", 1)
        self.assertTrue(core.is_excluded(e, ["firefox"]))
        self.assertTrue(core.is_excluded(e, [f"{self.home}/.cache/mozilla"]))
        self.assertFalse(core.is_excluded(e, [f"{self.home}/.cache/moz"]))   # not a path prefix
        self.assertFalse(core.is_excluded(e, ["chrome", ""]))

    def test_scan_hides_excluded(self):
        write(os.path.join(self.home, ".cache/secretproj/a"), 5000)
        write(os.path.join(self.home, ".cache/other/a"), 5000)
        res = core.scan_all(exclusions=["secretproj"])
        keys = [e.key for e in res.entries["user_cache"]]
        self.assertTrue(any(k.endswith("other") for k in keys))
        self.assertFalse(any(k.endswith("secretproj") for k in keys))
        self.assertGreaterEqual(res.hidden, 1)


class Helper(Base):
    def test_refuses_writable_install(self):
        fake = os.path.join(self.home, "ldc_core.py")
        write(fake, 10)
        os.chmod(fake, 0o666)                          # world-writable -> must be refused
        real = core.__file__
        core.__file__ = fake
        try:
            self.assertFalse(core.helper_install_ok())
        finally:
            core.__file__ = real

    @unittest.skipUnless(os.geteuid() == 0, "needs root")
    def test_helper_root_flow(self):
        p = write("/var/log/ldc_unit.log.1", 4000)
        keep = write("/var/log/ldc_unit_active.log", 4000)
        cat = core.CAT_BY_ID["old_logs"]
        e = [x for x in cat.enum() if x.key == p][0]
        payload = {"items": [{"cat": "old_logs", "key": p, "sig": e.sig},
                             {"cat": "old_logs", "key": "/etc/hostname", "sig": ""},
                             {"cat": "user_cache", "key": "/x", "sig": ""}]}
        import io, contextlib
        sys.stdin = io.StringIO(json.dumps(payload))
        out = io.StringIO()
        try:
            with contextlib.redirect_stdout(out):
                code = core.helper_main(strict=False)
        finally:
            sys.stdin = sys.__stdin__
            for f in (p, keep):
                if os.path.exists(f):
                    os.unlink(f)
        self.assertEqual(code, 0)
        res = [json.loads(l) for l in out.getvalue().splitlines()]
        by = {r["key"]: r for r in res}
        self.assertTrue(by[p]["ok"] and not by[p]["skipped"])
        self.assertTrue(by["/etc/hostname"]["skipped"])          # not a candidate
        self.assertFalse(by["/x"]["ok"])                        # not a system category
        self.assertTrue(os.path.exists("/etc/hostname"))


class Packages(Base):
    def test_kernel_protection(self):
        installed = ["6.5.0-10", "6.5.0-14", "6.8.0-40", "6.8.0-45", "6.8.0-50"]
        keep = core.kernels_to_keep(installed, "6.8.0-45")
        self.assertEqual(keep, {"6.8.0-45", "6.8.0-50", "6.8.0-40"})
        self.assertEqual(core._kernel_ver("linux-image-6.5.0-14-generic"), "6.5.0-14")
        self.assertEqual(core._kernel_ver("linux-headers-6.5.0-14"), "6.5.0-14")
        self.assertEqual(core._kernel_ver("linux-modules-extra-6.5.0-14-generic"), "6.5.0-14")
        self.assertIsNone(core._kernel_ver("linux-image-generic"))
        self.assertIsNone(core._kernel_ver("libfoo1"))

    def test_flatpak_parsing(self):
        out = ("        ID                               Branch   Op\n"
               " 1.     org.freedesktop.Platform.GL.default  22.08    r\n"
               " 2.     org.gnome.Platform.Locale        44       r\n")
        self.assertEqual(core.parse_flatpak_unused(out),
                         [("org.freedesktop.Platform.GL.default", "22.08"), ("org.gnome.Platform.Locale", "44")])
        sizes = core.parse_flatpak_sizes("org.gnome.Platform.Locale\t44\t12.5 MB\nx.y\t1\t300 bytes\n")
        self.assertEqual(sizes[("org.gnome.Platform.Locale", "44")], 12_500_000)
        self.assertEqual(sizes[("x.y", "1")], 300)

    def test_apt_busy_returns_bool(self):
        self.assertIsInstance(core.apt_busy(), bool)


class Misc(Base):
    def test_friendly_errors(self):
        import errno
        self.assertIn("permission", core.friendly(PermissionError()).lower())
        self.assertIn("in use", core.friendly(OSError(errno.EBUSY, "busy")).lower())
        self.assertIn("busy", core.friendly(RuntimeError("E: Could not get lock /var/lib/dpkg/lock")).lower())

    def test_settings_roundtrip_and_validation(self):
        s = core.load_settings()
        self.assertFalse(s["history"] or s["reminder"] or s["dry_run"])     # everything off by default
        s["exclusions"] = ["/data/keep", "Firefox"]
        s["dry_run"] = True
        core.save_settings(s)
        self.assertEqual(core.load_settings()["exclusions"], ["/data/keep", "Firefox"])
        with open(os.path.join(core.CONFIG_DIR, "settings.json"), "w") as f:
            json.dump({"dry_run": "yes", "reminder_min_mb": "lots", "exclusions": [1, "ok"]}, f)
        s = core.load_settings()
        self.assertFalse(s["dry_run"])
        self.assertEqual(s["reminder_min_mb"], 500)
        self.assertEqual(s["exclusions"], ["ok"])

    def test_history_is_off_by_default_and_has_no_filenames(self):
        res = [{"cat": "user_cache", "key": "/home/x/secret-file-name", "ok": True, "skipped": False, "freed": 100, "msg": ""}]
        core.log_history(res, core.load_settings())
        self.assertEqual(core.read_history(), [])
        s = core.load_settings(); s["history"] = True
        core.log_history(res, s)
        h = core.read_history()
        self.assertEqual(len(h), 1)
        self.assertEqual(h[0]["freed"], 100)
        self.assertNotIn("secret-file-name", json.dumps(h))
        s["dry_run"] = True
        core.log_history(res, s)
        self.assertEqual(len(core.read_history()), 1)       # previews are not logged
        core.clear_history()
        self.assertEqual(core.read_history(), [])

    def test_large_file_finder_lists_only(self):
        big = write(os.path.join(self.home, "Videos/old.mkv"), 300_000, age_days=400)
        write(os.path.join(self.home, "Videos/new.mkv"), 300_000)
        write(os.path.join(self.home, ".cache/huge"), 300_000, age_days=400)
        found = core.find_large_files(self.home, 100_000, 180)
        self.assertEqual([p for _s, _m, p in found], [big])
        self.assertTrue(os.path.exists(big))

    def test_cancelled_scan(self):
        write(os.path.join(self.home, ".cache/a/x"), 5000)
        def stop(done, total, cat):
            core.request_cancel()
        res = core.scan_all(progress=stop)
        self.assertTrue(res.cancelled)

    def test_every_category_is_sane(self):
        ids = [c.id for c in core.CATEGORIES]
        self.assertEqual(len(ids), len(set(ids)))
        for c in core.CATEGORIES:
            self.assertIn(c.scope, ("user", "system"))
            if c.id not in ("journal", "autoremove", "snaps", "flatpak_user", "flatpak_system", "docker"):
                self.assertTrue(c.roots, c.id)       # path categories must have an allow-list


def fake_proc(root, pid, comm, exe=None, argv=None, ppid=1, tty=0, fd0=None):
    d = os.path.join(root, str(pid))
    os.makedirs(os.path.join(d, "fd"))
    with open(os.path.join(d, "comm"), "w") as f:
        f.write(comm + "\n")
    if exe:
        os.symlink("/usr/bin/" + exe, os.path.join(d, "exe"))
    with open(os.path.join(d, "cmdline"), "wb") as f:
        f.write(b"\0".join(a.encode() for a in (argv or [comm])) + b"\0")
    with open(os.path.join(d, "stat"), "w") as f:
        f.write(f"{pid} ({comm}) S {ppid} {pid} {pid} {tty} {pid} 0")
    if fd0:
        os.symlink(fd0, os.path.join(d, "fd", "0"))


class OpenApps(Base):
    def setUp(self):
        super().setUp()
        self.proc = os.path.join(self.home, "proc")
        self.apps = os.path.join(self.home, "apps")
        os.makedirs(self.proc)
        os.makedirs(self.apps)
        for name, body in {
            "gedit.desktop": "[Desktop Entry]\nType=Application\nName=Text Editor\nName[de]=Texteditor\nExec=gedit %U\nCategories=Utility;\n",
            "vivaldi.desktop": "[Desktop Entry]\nType=Application\nName=Vivaldi\nExec=/opt/vivaldi/vivaldi %U\nCategories=Network;WebBrowser;\n",
            "htop.desktop": "[Desktop Entry]\nType=Application\nName=Htop\nExec=htop\nTerminal=true\n",
            "hidden.desktop": "[Desktop Entry]\nType=Application\nName=Hidden\nExec=hiddenapp\nNoDisplay=true\n",
            "fp.desktop": "[Desktop Entry]\nType=Application\nName=Flat App\nExec=/usr/bin/flatpak run --branch=stable --command=flatapp org.example.Flat @@u %u @@\n",
            "py.desktop": "[Desktop Entry]\nType=Application\nName=Py Tool\nExec=python3 /usr/share/pytool/pytool.py\n",
            "upd.desktop": "[Desktop Entry]\nType=Application\nName=Update Manager\nExec=mintupdate\n",
        }.items():
            with open(os.path.join(self.apps, name), "w") as f:
                f.write(body)

    def detect(self, **kw):
        return core.detect_open_apps(proc=self.proc, dirs=[self.apps], window_pids=kw.pop("window_pids", None),
                                     exclude_pids=kw.pop("exclude_pids", []), **kw)

    def names(self, apps):
        return {(a["kind"], a["name"]) for a in apps}

    def test_finds_browser_terminal_and_apps(self):
        fake_proc(self.proc, 10, "firefox", "firefox")
        fake_proc(self.proc, 11, "Isolated Web Co", "firefox", ["firefox", "-contentproc"])  # not a match, same app via exe
        fake_proc(self.proc, 12, "gnome-terminal-", "gnome-terminal-server")
        fake_proc(self.proc, 13, "gedit", "gedit")
        fake_proc(self.proc, 14, "vivaldi-bin", "vivaldi-bin", ["/opt/vivaldi/vivaldi"])
        got = self.names(self.detect())
        self.assertIn(("browser", "Firefox"), got)
        self.assertIn(("terminal", "GNOME Terminal"), got)
        self.assertIn(("app", "Text Editor"), got)
        self.assertIn(("browser", "Vivaldi"), got)       # found through its menu entry category

    def test_shell_sessions_only_listed_without_a_terminal_window(self):
        fake_proc(self.proc, 20, "bash", "bash", tty=34816, fd0="/dev/pts/3")
        fake_proc(self.proc, 21, "bash", "bash")          # no terminal -> a script, ignored
        self.assertEqual(self.names(self.detect()), {("terminal", "Terminal session (bash)")})
        fake_proc(self.proc, 22, "xterm", "xterm")
        got = self.names(self.detect())
        self.assertEqual(got, {("terminal", "XTerm")})   # the window covers its shells

    def test_own_process_and_its_terminal_are_not_listed(self):
        fake_proc(self.proc, 30, "gnome-terminal-", "gnome-terminal-server")
        fake_proc(self.proc, 31, "bash", "bash", ppid=30, tty=1, fd0="/dev/pts/1")
        fake_proc(self.proc, 32, "python3", "python3", ["python3", "/opt/linux-disk-cleanup/ldc_gui.py"], ppid=31)
        self.assertEqual(self.detect(exclude_pids=[30, 31, 32]), [])

    def test_ignores_hidden_text_apps_services_and_other_users(self):
        fake_proc(self.proc, 40, "hiddenapp", "hiddenapp")
        fake_proc(self.proc, 41, "htop", "htop")
        fake_proc(self.proc, 42, "gedit", "gedit", ["gedit", "--gapplication-service"])
        fake_proc(self.proc, 43, "mintupdate", "mintupdate")
        self.assertEqual(self.detect(), [])
        fake_proc(self.proc, 44, "gedit", "gedit")
        self.assertEqual(core.detect_open_apps(proc=self.proc, dirs=[self.apps], window_pids=None,
                                               exclude_pids=[], uid=os.getuid() + 12345), [])

    def test_flatpak_and_script_apps_are_recognised(self):
        fake_proc(self.proc, 50, "flatapp", "flatapp")
        fake_proc(self.proc, 51, "python3", "python3.12", ["python3", "/usr/share/pytool/pytool.py"])
        got = self.names(self.detect())
        self.assertIn(("app", "Flat App"), got)
        self.assertIn(("app", "Py Tool"), got)

    def test_window_filter_drops_windowless_apps_but_not_browsers_or_terminals(self):
        fake_proc(self.proc, 60, "gedit", "gedit")
        fake_proc(self.proc, 61, "firefox", "firefox")
        fake_proc(self.proc, 62, "xterm", "xterm")
        got = self.names(self.detect(window_pids={999}))
        self.assertEqual(got, {("browser", "Firefox"), ("terminal", "XTerm")})
        got = self.names(self.detect(window_pids={60}))
        self.assertIn(("app", "Text Editor"), got)

    def test_setting_defaults_to_on(self):
        self.assertTrue(core.load_settings()["warn_open_apps"])


if __name__ == "__main__":
    unittest.main()

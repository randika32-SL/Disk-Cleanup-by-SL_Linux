#!/usr/bin/env bash
set -e
if [ "$(id -u)" -ne 0 ]; then exec sudo bash "$0" "$@"; fi
rm -rf /opt/linux-disk-cleanup
rm -f /usr/bin/linux-disk-cleanup /usr/local/bin/linux-disk-cleanup \
      /usr/share/applications/linux-disk-cleanup.desktop \
      /usr/share/polkit-1/actions/org.slinux.diskcleanup.policy \
      /usr/share/icons/hicolor/scalable/apps/linux-disk-cleanup.svg \
      /usr/lib/systemd/user/linux-disk-cleanup-reminder.*
command -v update-desktop-database >/dev/null && update-desktop-database /usr/share/applications 2>/dev/null || true
echo "Disk Cleanup removed. (Your settings in ~/.config/linux-disk-cleanup are left in place.)"
